module com.example.labproject {
    requires javafx.controls;
    requires javafx.fxml;

    requires java.sql;
    requires jBCrypt;


    opens com.example.labproject to javafx.fxml;
    exports com.example.labproject;
    exports com.example.labproject.Models;
    exports com.example.labproject.DashBoards;

    opens com.example.labproject.Models;
    opens com.example.labproject.DashBoards;
    exports com.example.labproject.DashBoards.Admin;
    opens com.example.labproject.DashBoards.Admin;
    exports com.example.labproject.DashBoards.Teacher;
    opens com.example.labproject.DashBoards.Teacher;
    exports com.example.labproject.DashBoards.Student;
    opens com.example.labproject.DashBoards.Student;
    exports com.example.labproject.DashBoards.Admin.Courses to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.Courses to javafx.fxml;
    exports com.example.labproject.DashBoards.Admin.Teachers to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.Teachers to javafx.fxml;
    exports com.example.labproject.DashBoards.Admin.Rooms to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.Rooms to javafx.fxml;
    exports com.example.labproject.DashBoards.Admin.Students to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.Students to javafx.fxml;
    exports com.example.labproject.DashBoards.Admin.Classes to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.Classes to javafx.fxml;
    exports com.example.labproject.DashBoards.Admin.TimeTable to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.TimeTable to javafx.fxml;
    exports com.example.labproject.DashBoards.Admin.Department to javafx.fxml;
    opens com.example.labproject.DashBoards.Admin.Department to javafx.fxml;
    exports com.example.labproject.DashBoards.Student.Profile to javafx.fxml;
    opens com.example.labproject.DashBoards.Student.Profile to javafx.fxml;
    exports com.example.labproject.DashBoards.Student.TimeTable to javafx.fxml;
    opens com.example.labproject.DashBoards.Student.TimeTable to javafx.fxml;
    exports com.example.labproject.DashBoards.Teacher.Profile to javafx.fxml;
    opens com.example.labproject.DashBoards.Teacher.Profile to javafx.fxml;
    exports com.example.labproject.DashBoards.Teacher.Students to javafx.fxml;
    opens com.example.labproject.DashBoards.Teacher.Students to javafx.fxml;
    exports com.example.labproject.DashBoards.Teacher.TimeTable to javafx.fxml;
    opens com.example.labproject.DashBoards.Teacher.TimeTable to javafx.fxml;
}