package com.example.labproject.Models;

import javafx.beans.property.*;

public class Room {

    private final StringProperty roomID = new SimpleStringProperty();
    private final IntegerProperty floor = new SimpleIntegerProperty();
    private final IntegerProperty roomNo = new SimpleIntegerProperty();
    private final IntegerProperty capacity = new SimpleIntegerProperty();
    private final StringProperty department = new SimpleStringProperty();
    private final BooleanProperty[] availability = new BooleanProperty[2];

    public Room() {
        for (int i = 0; i < availability.length; i++) {
            availability[i] = new SimpleBooleanProperty(true); // Initially all time slots are available
        }
    }

    public Room(String roomID, int floor, int roomNo, int capacity, String department) {
        this();
        this.roomID.set(roomID);
        this.floor.set(floor);
        this.roomNo.set(roomNo);
        this.capacity.set(capacity);
        this.department.set(department);
    }

    public String getRoomID() {
        return roomID.get();
    }

    public StringProperty roomIDProperty() {
        return roomID;
    }

    public void setRoomID(String roomID) {
        this.roomID.set(roomID);
    }

    public int getFloor() {
        return floor.get();
    }

    public IntegerProperty floorProperty() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor.set(floor);
    }

    public int getRoomNo() {
        return roomNo.get();
    }

    public IntegerProperty roomNoProperty() {
        return roomNo;
    }

    public void setRoomNo(int roomNo) {
        this.roomNo.set(roomNo);
    }

    public int getCapacity() {
        return capacity.get();
    }

    public IntegerProperty capacityProperty() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity.set(capacity);
    }

    public String getDepartment() {
        return department.get();
    }

    public StringProperty departmentProperty() {
        return department;
    }

    public void setDepartment(String department) {
        this.department.set(department);
    }

    public BooleanProperty getAvailability(int index) {
        return availability[index];
    }

    public void setAvailability(int index, boolean available) {
        availability[index].set(available);
    }

    public void GenerateRoomID(int floor, int roomNo){
        roomID.set("F" + floor + "-R" + roomNo);
    }

    @Override
    public String toString() {
        return "Room{" +
                "roomID=" + roomID.get() +
                ", floor=" + floor.get() +
                ", roomNo=" + roomNo.get() +
                ", capacity=" + capacity.get() +
                ", department=" + department.get() +
                '}';
    }
}
