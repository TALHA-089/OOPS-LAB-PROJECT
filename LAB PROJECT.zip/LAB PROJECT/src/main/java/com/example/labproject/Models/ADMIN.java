package com.example.labproject.Models;

public class ADMIN {

    private String UserName;
    private String Password;

    public ADMIN(){}

    public ADMIN(String userName, String password){
        this.UserName = userName;
        this.Password = password;
    }
    public void setUserName(String userName){
        this.UserName = userName;
    }

    public String getUserName(){
        return this.UserName;
    }

    public void setPassword(String password){
        this.Password = password;
    }

    public String getPassword(){
        return this.Password;
    }
}
