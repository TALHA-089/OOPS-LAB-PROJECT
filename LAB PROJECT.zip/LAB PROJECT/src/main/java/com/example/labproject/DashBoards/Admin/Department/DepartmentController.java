package com.example.labproject.DashBoards.Admin.Department;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.DepartmentInfo;
import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DepartmentController {
    private String Department;

    public void setDepartment(String department) {
        this.Department = department;
    }

    public String getDepartment(){
        return this.Department;
    }

    @FXML
    private Button btnBack;

    @FXML
    private TableView<DepartmentInfo> DepartmentTable;
    @FXML
    private TableColumn<DepartmentInfo, String> NameColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> TeachersColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> CoursesColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> StudentsColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> RoomsColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> ClassesColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> CampusColumn;
    @FXML
    private TableColumn<DepartmentInfo, String> BlockColumn;

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    private ObservableList<DepartmentInfo> departmentData = FXCollections.observableArrayList();


    public void loadDepartmentData(String department) {
        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM DEPARTMENTS WHERE DEPARTMENT_NAME = ?");
            preparedStatement.setString(1, department);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String courses = resultSet.getString("Courses");
                String teachers = resultSet.getString("Teachers");
                String students = resultSet.getString("Students");
                String rooms = resultSet.getString("Rooms");
                String classes = resultSet.getString("Classes");
                String campus = resultSet.getString("Campus");
                String block = resultSet.getString("Block");

                DepartmentInfo departmentInfo = new DepartmentInfo(
                        department,
                        teachers,
                        courses,
                        students,
                        rooms,
                        classes,
                        campus,
                        block
                );

                departmentData.add(departmentInfo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        initializeTableView();
    }

    private void initializeTableView() {
        NameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        TeachersColumn.setCellValueFactory(new PropertyValueFactory<>("teachers"));
        CoursesColumn.setCellValueFactory(new PropertyValueFactory<>("courses"));
        StudentsColumn.setCellValueFactory(new PropertyValueFactory<>("students"));
        RoomsColumn.setCellValueFactory(new PropertyValueFactory<>("rooms"));
        ClassesColumn.setCellValueFactory(new PropertyValueFactory<>("classes"));
        CampusColumn.setCellValueFactory(new PropertyValueFactory<>("campus"));
        BlockColumn.setCellValueFactory(new PropertyValueFactory<>("block"));

        DepartmentTable.setItems(departmentData);
    }

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 360, 550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.show();
    }
}
