package com.example.labproject.DashBoards.Student.TimeTable;

import com.example.labproject.DashBoards.Student.StudentDashBoard;
import com.example.labproject.Models.Classes;
import com.example.labproject.Models.STUDENT;
import com.example.labproject.Models.TimeTableEntry;
import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;

public class StudentTimeTableController {

    public STUDENT student = new STUDENT();

    @FXML
    private Label ClassLabel;
    @FXML
    private Button btnBack;
    @FXML
    private TableView<TimeTableEntry> TimeTable;
    @FXML
    private TableColumn<TimeTableEntry, String> CourseColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> TeacherColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> DayColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> TimeSlotColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> RoomColumn;

    final String DB_URL = "jdbc:mysql://localhost:3306/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    private ObservableList<String> courseList = FXCollections.observableArrayList();
    private ObservableList<TimeTableEntry> timeTableData = FXCollections.observableArrayList();

    public void loadStudentInfo(String enrollment) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM STUDENT WHERE ID = ?");
            preparedStatement.setString(1, enrollment);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                student.setID(enrollment);
                student.setName(resultSet.getString("NAME"));
                student.setEmail(resultSet.getString("EMAIL"));
                student.setPassword(resultSet.getString("PASSWORD"));
                student.setSemester(String.valueOf(resultSet.getInt("Semester")));
                student.setDepartment(resultSet.getString("DEPARTMENT_NAME"));
                Classes classes = new Classes();
                classes.setClassID(resultSet.getString("Class"));
                student.setClasses(classes);
                ClassLabel.setText("CLASS : " + student.getClasses().getClassID());
                loadCoursesForClass(student.getClasses().getClassID());
                loadTimeTableData();
                initializeTableView();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadCoursesForClass(String classID) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT COURSES FROM CLASSES WHERE CLASSID = ?");
            preparedStatement.setString(1, classID);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String courses = resultSet.getString("COURSES");
                courseList.addAll(Arrays.asList(courses.split(", ")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadTimeTableData() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            for (String course : courseList) {
                PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM " + student.getDepartment() + "_TimeTable WHERE COURSE = ?");
                preparedStatement.setString(1, course);
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    String courseName = resultSet.getString("Course");
                    String teacher = resultSet.getString("Teacher");
                    String day = resultSet.getString("Day");
                    String timeSlot = resultSet.getString("TimeSlot");
                    String room = resultSet.getString("Room");
                    TimeTableEntry timeTableEntry = new TimeTableEntry(courseName, teacher, day, timeSlot, room);
                    timeTableData.add(timeTableEntry);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initializeTableView() {
        CourseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        TeacherColumn.setCellValueFactory(new PropertyValueFactory<>("teacher"));
        DayColumn.setCellValueFactory(new PropertyValueFactory<>("day"));
        TimeSlotColumn.setCellValueFactory(new PropertyValueFactory<>("timeSlot"));
        RoomColumn.setCellValueFactory(new PropertyValueFactory<>("room"));
        TimeTable.setItems(timeTableData);
    }

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 300, 350);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(300);
        stage.setMinHeight(350);
        stage.setMaxWidth(300);
        stage.setMaxHeight(350);
        stage.setScene(scene);
        StudentDashBoard controller = fxmlLoader.getController();
        controller.GlobalStudent.setID(student.getID());
        stage.show();
    }
}
