package com.example.labproject.Models;

public class DepartmentInfo {
    private String name;
    private String teachers;
    private String courses;
    private String students;
    private String rooms;
    private String classes;
    private String campus;
    private String block;

    public DepartmentInfo(String name, String teachers, String courses, String students, String rooms, String classes, String campus, String block) {
        this.name = name;
        this.teachers = teachers;
        this.courses = courses;
        this.students = students;
        this.rooms = rooms;
        this.classes = classes;
        this.campus = campus;
        this.block = block;
    }

    public String getName() { return name; }
    public String getTeachers() { return teachers; }
    public String getCourses() { return courses; }
    public String getStudents() { return students; }
    public String getRooms() { return rooms; }
    public String getClasses() { return classes; }
    public String getCampus() { return campus; }
    public String getBlock() { return block; }
}

