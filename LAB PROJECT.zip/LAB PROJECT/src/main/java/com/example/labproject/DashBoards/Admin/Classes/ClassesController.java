package com.example.labproject.DashBoards.Admin.Classes;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.Classes;
import com.example.labproject.Models.Courses;
import com.example.labproject.Models.STUDENT;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.University;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ClassesController {

    private String Department;

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getDepartment() {
        return this.Department;
    }

    @FXML
    private Button btnBack;
    @FXML
    private ComboBox<Integer> cbClassSemester;
    @FXML
    private ListView<Courses> CoursesLV;
    @FXML
    private TableView<Classes> ClassesTable;
    @FXML
    private TableColumn<Classes, String> IDColumn;
    @FXML
    private TableColumn<Classes, Integer> SemesterColumn;
    @FXML
    private TableColumn<Classes, String> DepartmentColumn;
    @FXML
    private TableColumn<Classes, String> StudentsColumn;
    @FXML
    private TableColumn<Classes, String> CoursesColumn;

    private ObservableList<Classes> ClassesList = FXCollections.observableArrayList();
    private ObservableList<Courses> AllCoursesList = FXCollections.observableArrayList();

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    protected void initialize() {
        IDColumn.setCellValueFactory(new PropertyValueFactory<>("ClassID"));
        SemesterColumn.setCellValueFactory(new PropertyValueFactory<>("semester"));
        DepartmentColumn.setCellValueFactory(new PropertyValueFactory<>("Department"));
        StudentsColumn.setCellValueFactory(cellData -> {
            List<STUDENT> studentList = cellData.getValue().getStudentsList();
            if (studentList != null && !studentList.isEmpty()) {
                String studentNames = studentList.stream()
                        .map(STUDENT::getName)
                        .collect(Collectors.joining(", "));
                return new SimpleStringProperty(studentNames);
            } else {
                return new SimpleStringProperty("");
            }
        });
        CoursesColumn.setCellValueFactory(cellData -> {
            List<Courses> coursesList = cellData.getValue().getCoursesList();
            if (coursesList != null && !coursesList.isEmpty()) {
                String courseNames = coursesList.stream()
                        .map(Courses::getCourseName)
                        .collect(Collectors.joining(", "));
                return new SimpleStringProperty(courseNames);
            } else {
                return new SimpleStringProperty("");
            }
        });
        cbClassSemester.getItems().addAll(1, 2, 3, 4, 5, 6, 7, 8);
        CoursesLV.setItems(AllCoursesList);
        CoursesLV.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        CoursesLV.setCellFactory(listView -> new ListCell<>() {
            @Override
            protected void updateItem(Courses course, boolean empty) {
                super.updateItem(course, empty);
                if (empty || course == null) {
                    setText(null);
                } else {
                    setText(course.getCourseName() + " (" + course.getCourseCode() + ")");
                }
            }
        });
        ClassesTable.setItems(ClassesList);

    }

    @FXML
    protected void AddClass() {

        int semester = cbClassSemester.getValue();
        List<Courses> selectedCourses = CoursesLV.getSelectionModel().getSelectedItems();
        List<STUDENT> studentsList = new ArrayList<>();

        Classes newClass = new Classes();
        newClass.setSemester(String.valueOf(semester));
        newClass.setDepartment(Department);
        newClass.GenerateClassID();
        newClass.setStudentsList(studentsList);
        newClass.setCoursesList(selectedCourses);


        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String courses = selectedCourses.stream()
                    .map(Courses::getCourseName)
                    .collect(Collectors.joining(", "));
            String students = "";

            PreparedStatement preparedStatement = conn.prepareStatement(
                    "INSERT INTO CLASSES (CLASSID, SEMESTER, DEPARTMENT, STUDENTS, COURSES) VALUES (?, ?, ?, ?, ?)");
            preparedStatement.setString(1, newClass.getClassID());
            preparedStatement.setInt(2, semester);
            preparedStatement.setString(3, Department);
            preparedStatement.setString(4, students);
            preparedStatement.setString(5, courses);

            preparedStatement.executeUpdate();

            String updateDepartmentQuery = "UPDATE DEPARTMENTS SET CLASSES = CONCAT(CLASSES, ?) WHERE DEPARTMENT_NAME = ?";
            preparedStatement = conn.prepareStatement(updateDepartmentQuery);
            preparedStatement.setString(1, ", " + newClass.getClassID());
            preparedStatement.setString(2, getDepartment());

            int updatedDepartmentRows = preparedStatement.executeUpdate();

            if (updatedDepartmentRows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Department Students Updated Successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to Update Department Students.");
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        ClassesList.add(newClass);
    }

    private void showAlert(Alert.AlertType alertType, String title, String s) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(s);
        alert.showAndWait();
    }

    @FXML
    protected void EditClass() {
        Classes selectedClass = ClassesTable.getSelectionModel().getSelectedItem();
        if (selectedClass != null) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
                List<Courses> selectedCourses = CoursesLV.getSelectionModel().getSelectedItems();
                int semester = cbClassSemester.getValue();
                selectedClass.setSemester(String.valueOf(semester));
                selectedClass.setCoursesList(selectedCourses);

                String courses = selectedCourses.stream()
                        .map(Courses::getCourseName)
                        .collect(Collectors.joining(", "));
                String students = selectedClass.getStudentsList().stream()
                        .map(STUDENT::getName)
                        .collect(Collectors.joining(", "));

                PreparedStatement preparedStatement = conn.prepareStatement(
                        "UPDATE CLASSES SET SEMESTER = ?, COURSES = ? WHERE CLASSID = ?");
                preparedStatement.setInt(1, semester);
                preparedStatement.setString(2, courses);
                preparedStatement.setString(3, selectedClass.getClassID());

                preparedStatement.executeUpdate();

                ClassesList.set(ClassesList.indexOf(selectedClass), selectedClass);

                showAlert(Alert.AlertType.INFORMATION, "Success", "Class Updated Successfully.");
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to Update Class.");
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "No Class Selected.");
        }
    }
    @FXML
    protected void RemoveClass() {
        Classes selectedClass = ClassesTable.getSelectionModel().getSelectedItem();
        if (selectedClass != null) {
            try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
                PreparedStatement preparedStatement = conn.prepareStatement(
                        "DELETE FROM CLASSES WHERE CLASSID = ?");
                preparedStatement.setString(1, selectedClass.getClassID());

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    String updateDepartmentQuery = "UPDATE DEPARTMENTS SET CLASSES = REPLACE(CLASSES, ?, '') WHERE DEPARTMENT_NAME = ?";
                    preparedStatement = conn.prepareStatement(updateDepartmentQuery);
                    preparedStatement.setString(1, ", " + selectedClass.getClassID());
                    preparedStatement.setString(2, getDepartment());

                    preparedStatement.executeUpdate();

                    // Cleanup the formatting in the CLASSES column
                    String cleanUpQuery = "UPDATE DEPARTMENTS SET CLASSES = TRIM(BOTH ', ' FROM REPLACE(REPLACE(CLASSES, ', ,', ','), ' ,', ',')) WHERE DEPARTMENT_NAME = ?";
                    preparedStatement = conn.prepareStatement(cleanUpQuery);
                    preparedStatement.setString(1, getDepartment());

                    preparedStatement.executeUpdate();

                    ClassesList.remove(selectedClass);

                    showAlert(Alert.AlertType.INFORMATION, "Success", "Class Removed Successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to Remove Class.");
                }

            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to Remove Class.");
            }
        } else {
            showAlert(Alert.AlertType.WARNING, "Warning", "No Class Selected.");
        }
    }

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 360, 550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.setScene(scene);
        stage.show();
    }

    public void loadClassesFromDataBase(String department) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM CLASSES WHERE DEPARTMENT = ?");
            preparedStatement.setString(1, department);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Classes newClass = new Classes();
                newClass.setClassID(resultSet.getString("CLASSID"));
                newClass.setSemester(String.valueOf(resultSet.getInt("SEMESTER")));
                newClass.setDepartment(resultSet.getString("DEPARTMENT"));
                List<STUDENT> studentsList = loadStudentsForClass(conn, newClass.getClassID());
                newClass.setStudentsList(studentsList);
                List<Courses> coursesList = loadCoursesForClass(conn, newClass.getClassID());
                newClass.setCoursesList(coursesList);
                ClassesList.add(newClass);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private List<Courses> loadCoursesForClass(Connection conn, String classID) throws SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement("SELECT COURSES FROM CLASSES WHERE CLASSID = ?");
        preparedStatement.setString(1, classID);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            String courses = resultSet.getString("COURSES");
            List<String> courseNames = Arrays.asList(courses.split(", "));
            List<Courses> coursesList = new ArrayList<>();
            for (String courseName : courseNames) {
                Courses course = new Courses();
                course.setCourseName(courseName);
                coursesList.add(course);
            }
            return coursesList;
        }
        return new ArrayList<>();
    }

    private List<STUDENT> loadStudentsForClass(Connection conn, String classID) throws SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement("SELECT STUDENTS FROM CLASSES WHERE CLASSID = ?");
        preparedStatement.setString(1, classID);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            String students = resultSet.getString("STUDENTS");
            List<String> studentNames = Arrays.asList(students.split(", "));
            List<STUDENT> studentList = new ArrayList<>();
            for (String studentName : studentNames) {
                STUDENT student = new STUDENT();
                student.setName(studentName);
                studentList.add(student);
            }
            return studentList;
        }
        return new ArrayList<>();
    }

    public void loadAllCoursesFromDataBase(String department) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM COURSES WHERE DEPARTMENT_NAME = ?");
            preparedStatement.setString(1,department);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Courses course = new Courses();
                course.setCourseName(resultSet.getString("CourseName"));
                course.setCourseCode(resultSet.getString("CourseCode"));
                TEACHER teacher = new TEACHER();
                teacher.setName(resultSet.getString("Teacher"));
                course.setCourseTeacher(teacher);
                course.setCreditHours(resultSet.getInt("CreditHours"));
                course.setDepartment(department);
                AllCoursesList.add(course);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
