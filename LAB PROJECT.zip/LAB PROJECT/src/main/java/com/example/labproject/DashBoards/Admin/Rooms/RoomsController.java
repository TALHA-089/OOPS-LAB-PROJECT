package com.example.labproject.DashBoards.Admin.Rooms;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.Room;
import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class RoomsController implements Initializable {

    private String Department;

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getDepartment() {
        return this.Department;
    }

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    private Button btnBack;

    @FXML
    private TextField tfFloorNo;
    @FXML
    private TextField tfRoomNo;
    @FXML
    private TextField tfCapacity;

    @FXML
    private TableView<Room> RoomsTable;
    @FXML
    private TableColumn<Room, String> RoomIDColumn;
    @FXML
    private TableColumn<Room, Integer> FloorNoColumn;
    @FXML
    private TableColumn<Room, Integer> RoomNoColumn;
    @FXML
    private TableColumn<Room, Integer> CapacityColumn;
    @FXML
    private TableColumn<Room, String> DepartmentColumn;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        RoomIDColumn.setCellValueFactory(cellData -> cellData.getValue().roomIDProperty());
        FloorNoColumn.setCellValueFactory(cellData -> cellData.getValue().floorProperty().asObject());
        RoomNoColumn.setCellValueFactory(cellData -> cellData.getValue().roomNoProperty().asObject());
        CapacityColumn.setCellValueFactory(cellData -> cellData.getValue().capacityProperty().asObject());
        DepartmentColumn.setCellValueFactory(cellData -> cellData.getValue().departmentProperty());

        loadRoomData();
    }

    private void loadRoomData() {
        ObservableList<Room> roomList = FXCollections.observableArrayList();
        String sql = "SELECT * FROM ROOMS";

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Room room = new Room();
                room.setRoomID(rs.getString("RoomID"));
                room.setFloor(rs.getInt("Floor"));
                room.setRoomNo(rs.getInt("RoomNo"));
                room.setCapacity(rs.getInt("CAPACITY"));
                room.setDepartment(rs.getString("DEPARTMENT"));

                roomList.add(room);
            }

            RoomsTable.setItems(roomList);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),360,550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.show();
    }

    @FXML
    protected void AddRoom() {
        if (tfFloorNo.getText().isEmpty() || tfRoomNo.getText().isEmpty() || tfCapacity.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Please fill out all fields.");
            return;
        }

        try {
            int floor = Integer.parseInt(tfFloorNo.getText());
            int roomNo = Integer.parseInt(tfRoomNo.getText());
            int capacity = Integer.parseInt(tfCapacity.getText());

            Room room = new Room();
            room.setFloor(floor);
            room.setRoomNo(roomNo);
            room.setCapacity(capacity);
            room.GenerateRoomID(floor, roomNo);
            room.setDepartment(this.getDepartment());

            if (!isRoomIDUnique(room.getRoomID())) {
                showAlert(Alert.AlertType.ERROR, "ERROR!", "Room ID already exists.");
                return;
            }

            String sql = "INSERT INTO ROOMS (ROOMID, Floor, RoomNo, CAPACITY, DEPARTMENT) VALUES (?, ?, ?, ?, ?)";
            try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, room.getRoomID());
                stmt.setInt(2, floor);
                stmt.setInt(3, roomNo);
                stmt.setInt(4, capacity);
                stmt.setString(5, room.getDepartment());

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "SUCCESS", "Room added successfully!");
                    updateDepartmentRooms(room.getDepartment(), room.getRoomID(), true);
                    tfFloorNo.clear();
                    tfRoomNo.clear();
                    tfCapacity.clear();
                    loadRoomData();
                }
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Invalid input for floor, room number, or capacity.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to add room. Please try again.");
        }
    }

    @FXML
    protected void EditRoom() {
        Room selectedRoom = RoomsTable.getSelectionModel().getSelectedItem();
        if (selectedRoom == null) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Please select a room to edit.");
            return;
        }

        if (tfFloorNo.getText().isEmpty() || tfRoomNo.getText().isEmpty() || tfCapacity.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Please fill out all fields.");
            return;
        }

        try {
            int floor = Integer.parseInt(tfFloorNo.getText());
            int roomNo = Integer.parseInt(tfRoomNo.getText());
            int capacity = Integer.parseInt(tfCapacity.getText());

            String oldRoomID = selectedRoom.getRoomID();

            selectedRoom.setFloor(floor);
            selectedRoom.setRoomNo(roomNo);
            selectedRoom.setCapacity(capacity);
            selectedRoom.GenerateRoomID(floor, roomNo);

            String sql = "UPDATE ROOMS SET ROOMID = ?, Floor = ?, RoomNo = ?, CAPACITY = ? WHERE ROOMID = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, selectedRoom.getRoomID());
                stmt.setInt(2, floor);
                stmt.setInt(3, roomNo);
                stmt.setInt(4, capacity);
                stmt.setString(5, oldRoomID);

                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    String updateDepartmentQuery = "UPDATE DEPARTMENTS SET ROOMS = REPLACE(ROOMS, ?, ?) WHERE DEPARTMENT_NAME = ?";
                    try (PreparedStatement updateDeptStmt = conn.prepareStatement(updateDepartmentQuery)) {
                        updateDeptStmt.setString(1, oldRoomID + ", ");
                        updateDeptStmt.setString(2, selectedRoom.getRoomID() + ", ");
                        updateDeptStmt.setString(3, this.getDepartment());

                        int deptRowsAffected = updateDeptStmt.executeUpdate();
                        if (deptRowsAffected > 0) {
                            showAlert(Alert.AlertType.INFORMATION, "SUCCESS", "Room updated successfully!");
                            tfFloorNo.clear();
                            tfRoomNo.clear();
                            tfCapacity.clear();
                            loadRoomData();
                        } else {
                            showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to update department's room list.");
                        }
                    }
                } else {
                    showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to update room.");
                }
            }
        } catch (NumberFormatException e) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Invalid input for floor, room number, or capacity.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to update room. Please try again.");
        }
    }

    @FXML
    protected void RemoveRoom() {
        Room selectedRoom = RoomsTable.getSelectionModel().getSelectedItem();
        if (selectedRoom == null) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Please select a room to remove.");
            return;
        }

        try {
            String sql = "DELETE FROM ROOMS WHERE ROOMID = ?";
            try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, selectedRoom.getRoomID());

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "SUCCESS", "Room removed successfully!");
                    updateDepartmentRooms(selectedRoom.getDepartment(), selectedRoom.getRoomID(), false);
                    tfFloorNo.clear();
                    tfRoomNo.clear();
                    tfCapacity.clear();
                    loadRoomData();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to remove room. Please try again.");
        }
    }

    private boolean isRoomIDUnique(String roomID) {
        String sql = "SELECT COUNT(*) FROM ROOMS WHERE ROOMID = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, roomID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count == 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void updateDepartmentRooms(String department, String roomID, boolean addRoom) {
        String updateDepartmentQuery;
        if (addRoom) {
            updateDepartmentQuery = "UPDATE DEPARTMENTS SET ROOMS = CONCAT(IFNULL(ROOMS, ''), ?, ' ') WHERE DEPARTMENT_NAME = ?";
        } else {
            updateDepartmentQuery = "UPDATE DEPARTMENTS SET ROOMS = REPLACE(ROOMS, ?, '') WHERE DEPARTMENT_NAME = ?";
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement updateDeptStmt = conn.prepareStatement(updateDepartmentQuery)) {

            updateDeptStmt.setString(1, roomID + ", ");
            updateDeptStmt.setString(2, department);
            updateDeptStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
