package com.example.labproject.DashBoards.Admin;

import com.example.labproject.DashBoards.Admin.Classes.ClassesController;
import com.example.labproject.DashBoards.Admin.Courses.CourseController;
import com.example.labproject.DashBoards.Admin.Department.DepartmentController;
import com.example.labproject.DashBoards.Admin.Rooms.RoomsController;
import com.example.labproject.DashBoards.Admin.Students.StudentsController;
import com.example.labproject.DashBoards.Admin.Teachers.TeachersController;
import com.example.labproject.DashBoards.Admin.TimeTable.TimeTableController;
import com.example.labproject.University;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminDashBoard {
    private String Department;
    @FXML
    private Button btnCourses;
    @FXML
    private Button btnTeachers;
    @FXML
    private Button btnRooms;
    @FXML
    private Button btnStudents;
    @FXML
    private Button btnClasses;
    @FXML
    private Button btnBack;

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/SelectDepartment.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 350, 400);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(350);
        stage.setMinHeight(400);
        stage.setMaxWidth(350);
        stage.setMaxHeight(400);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void CustomizeCourses() throws IOException{
        Stage stage = (Stage) btnCourses.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Courses/Courses.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),630,800);
        stage.setMinHeight(800);
        stage.setMinWidth(630);
        stage.setMaxWidth(630);
        stage.setMaxHeight(800);
        CourseController controller = fxmlLoader.getController();
        controller.setDepartment(this.getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void CustomizeTeachers() throws IOException {
        Stage stage = (Stage) btnTeachers.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Teachers/Teachers.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),630,800);
        stage.setMinHeight(800);
        stage.setMinWidth(630);
        stage.setMaxWidth(630);
        stage.setMaxHeight(800);
        TeachersController controller = fxmlLoader.getController();
        controller.setDepartment(this.getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void CustomizeRooms() throws IOException {
        Stage stage = (Stage) btnRooms.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Rooms/Rooms.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),630,800);
        stage.setMinHeight(800);
        stage.setMinWidth(630);
        stage.setMaxWidth(630);
        stage.setMaxHeight(800);
        RoomsController controller = fxmlLoader.getController();
        controller.setDepartment(this.getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void CustomizeStudents() throws IOException {
        Stage stage = (Stage) btnStudents.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Students/Students.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),630,800);
        stage.setMinHeight(800);
        stage.setMinWidth(630);
        stage.setMaxWidth(630);
        stage.setMaxHeight(800);
        StudentsController controller = fxmlLoader.getController();
        controller.setDepartment(getDepartment());
        controller.loadStudentsFromDatabase(getDepartment());
        controller.loadClassesFromDataBase(getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void CustomizeClasses() throws IOException {
        Stage stage = (Stage) btnClasses.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Classes/Classes.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),630,800);
        stage.setMinHeight(800);
        stage.setMinWidth(630);
        stage.setMaxWidth(630);
        stage.setMaxHeight(800);
        ClassesController controller = fxmlLoader.getController();
        controller.setDepartment(this.getDepartment());
        controller.loadClassesFromDataBase(getDepartment());
        controller.loadAllCoursesFromDataBase(getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void GoToTimeTable() throws IOException {
        Stage stage = (Stage) btnClasses.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/TimeTable/TimeTable.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),600,450);
        stage.setMinHeight(450);
        stage.setMinWidth(600);
        stage.setMaxWidth(600);
        stage.setMaxHeight(450);
        TimeTableController controller = fxmlLoader.getController();
        controller.setDepartment(this.getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    protected void GoToDepartment() throws IOException {
        Stage stage = (Stage) btnClasses.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Department/DepartmentInfo.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),630,450);
        stage.setMinHeight(450);
        stage.setMinWidth(630);
        stage.setMaxWidth(630);
        stage.setMaxHeight(450);
        DepartmentController controller = fxmlLoader.getController();
        controller.setDepartment(this.getDepartment());
        controller.loadDepartmentData(getDepartment());
        stage.setScene(scene);
        stage.show();
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getDepartment(){
        return this.Department;
    }


}
