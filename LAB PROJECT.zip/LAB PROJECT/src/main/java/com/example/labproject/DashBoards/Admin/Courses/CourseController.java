package com.example.labproject.DashBoards.Admin.Courses;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.Courses;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.University;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CourseController {

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    private Button btnBack;

    @FXML
    private TextField tfCourseName;
    @FXML
    private TextField tfCourseCode;
    @FXML
    private ComboBox<String> cbCourseTeacher;
    @FXML
    private ComboBox<Integer> cbCreditHours;
    @FXML
    private TableView<Courses> CoursesTable;

    @FXML
    private TableColumn<Courses,String> NameColumn;
    @FXML
    private TableColumn<Courses,String> CodeColumn;
    @FXML
    private TableColumn<Courses, String> TeacherColumn;
    @FXML
    private TableColumn<Courses,Integer> CreditColumn;
    @FXML
    private TableColumn<Courses,String> DepartmentColumn;

    private ObservableList<Courses> courseList = FXCollections.observableArrayList();
    private ObservableList<TEACHER> TeacherList = FXCollections.observableArrayList();

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),360,550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.show();
    }

    @FXML
    protected void AddCourse() {
        String CourseName = tfCourseName.getText();
        String CourseCode = tfCourseCode.getText();
        String SelectedTeacher = cbCourseTeacher.getValue();
        if (SelectedTeacher == null || SelectedTeacher.isEmpty()) {
            SelectedTeacher = "DummyTeacher";  // Use a dummy teacher if no teacher is selected
        }
        Integer CreditHours = cbCreditHours.getValue();

        if (CourseName.isEmpty() || CourseCode.isEmpty() || CreditHours == null || CreditHours == 0) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill out all the fields.");
            return;
        }

        for (Courses course : courseList) {
            if (Objects.equals(CourseCode, course.getCourseCode()) || SelectedTeacher.equals(course.getCourseTeacher().getName())) {
                showAlert(Alert.AlertType.ERROR, "Error", "Course Teacher or Code already taken.");
                return;
            }
        }

        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            String insertCourseQuery = "INSERT INTO COURSES (CourseName, CourseCode, Teacher, CreditHours, DEPARTMENT_NAME) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(insertCourseQuery);
            preparedStatement.setString(1, CourseName);
            preparedStatement.setString(2, CourseCode);
            preparedStatement.setString(3, SelectedTeacher);
            preparedStatement.setInt(4, CreditHours);
            preparedStatement.setString(5, getDepartment());

            int addedRows = preparedStatement.executeUpdate();

            if (addedRows > 0) {
                String finalSelectedTeacher = SelectedTeacher;
                TEACHER teacher = TeacherList.stream()
                        .filter(t -> t.getName().equals(finalSelectedTeacher))
                        .findFirst()
                        .orElse(null);

                Courses newCourse = new Courses(CourseName, CourseCode, teacher, CreditHours, getDepartment());
                courseList.add(newCourse);

                clearFields();

                showAlert(Alert.AlertType.INFORMATION, "Success", "Course added successfully.");

                String updateDepartmentQuery = "UPDATE DEPARTMENTS SET Courses = CONCAT(Courses, ?) WHERE DEPARTMENT_NAME = ?";
                preparedStatement = conn.prepareStatement(updateDepartmentQuery);
                preparedStatement.setString(1, ", " + CourseName);
                preparedStatement.setString(2, getDepartment());

                int updatedDepartmentRows = preparedStatement.executeUpdate();

                if (updatedDepartmentRows > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Department courses updated successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to update department courses.");
                }

                if (!SelectedTeacher.equals("DummyTeacher")) {  // Only update teacher if it's not a dummy teacher
                    String updateTeacherQuery = "UPDATE TEACHER SET COURSE = ? WHERE NAME = ?";
                    preparedStatement = conn.prepareStatement(updateTeacherQuery);
                    preparedStatement.setString(1, CourseName);
                    preparedStatement.setString(2, SelectedTeacher);

                    int updatedTeacherRows = preparedStatement.executeUpdate();

                    if (updatedTeacherRows > 0) {
                        showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher's course updated successfully.");
                    } else {
                        showAlert(Alert.AlertType.ERROR, "Error", "Failed to update teacher's course.");
                    }
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to add course.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while adding course: " + e.getMessage());
            e.printStackTrace();
        }
    }



    @FXML
    protected void RemoveCourse() {
        Courses selectedCourse = CoursesTable.getSelectionModel().getSelectedItem();
        if (selectedCourse == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a course to remove.");
            return;
        }

        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            String deleteQuery = "DELETE FROM COURSES WHERE CourseCode=?";
            PreparedStatement preparedStatement = conn.prepareStatement(deleteQuery);
            preparedStatement.setString(1, selectedCourse.getCourseCode());

            int deletedRows = preparedStatement.executeUpdate();

            if (deletedRows > 0) {
                courseList.remove(selectedCourse);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Course removed successfully.");


                String updateDepartmentQuery = "UPDATE DEPARTMENTS SET Courses = REPLACE(Courses, ?, '') WHERE DEPARTMENT_NAME = ?";
                preparedStatement = conn.prepareStatement(updateDepartmentQuery);
                preparedStatement.setString(1, selectedCourse.getCourseName());
                preparedStatement.setString(2, getDepartment());

                int updatedDepartmentRows = preparedStatement.executeUpdate();

                if (updatedDepartmentRows > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Department courses updated successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to update department courses.");
                }


                String updateTeacherQuery = "UPDATE TEACHER SET COURSE = NULL WHERE COURSE = ?";
                preparedStatement = conn.prepareStatement(updateTeacherQuery);
                preparedStatement.setString(1, selectedCourse.getCourseName());

                int updatedTeacherRows = preparedStatement.executeUpdate();

                if (updatedTeacherRows > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher's course cleared successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to clear teacher's course.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to remove course.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while removing course: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    protected void EditCourse() {
        Courses selectedCourse = CoursesTable.getSelectionModel().getSelectedItem();
        if (selectedCourse == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a course to edit.");
            return;
        }

        String newCourseName = tfCourseName.getText();
        String newCourseCode = tfCourseCode.getText();
        String newTeacher = cbCourseTeacher.getValue();
        Integer newCreditHours = cbCreditHours.getValue();

        if (newCourseName.isEmpty() || newCourseCode.isEmpty() || newTeacher == null || newCreditHours == null || newCreditHours == 0) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill out all the fields.");
            return;
        }

        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            String updateQuery = "UPDATE COURSES SET CourseName=?, CourseCode=?, Teacher=?, CreditHours=?, DEPARTMENT_NAME=? WHERE CourseCode=?";
            PreparedStatement preparedStatement = conn.prepareStatement(updateQuery);
            preparedStatement.setString(1, newCourseName);
            preparedStatement.setString(2, newCourseCode);
            preparedStatement.setString(3, newTeacher);
            preparedStatement.setInt(4, newCreditHours);
            preparedStatement.setString(5, getDepartment());
            preparedStatement.setString(6, selectedCourse.getCourseCode());

            int updatedRows = preparedStatement.executeUpdate();

            if (updatedRows > 0) {
                TEACHER teacher = TeacherList.stream()
                        .filter(t -> t.getName().equals(newTeacher))
                        .findFirst()
                        .orElseThrow(() -> new IllegalStateException("Selected teacher not found."));

                selectedCourse.setCourseName(newCourseName);
                selectedCourse.setCourseCode(newCourseCode);
                selectedCourse.setCourseTeacher(teacher);
                selectedCourse.setCreditHours(newCreditHours);
                selectedCourse.setDepartment(getDepartment());

                CoursesTable.refresh();

                clearFields();

                showAlert(Alert.AlertType.INFORMATION, "Success", "Course updated successfully.");


                String updateDepartmentQuery = "UPDATE DEPARTMENTS SET Courses = REPLACE(Courses, ?, ?) WHERE DEPARTMENT_NAME = ?";
                preparedStatement = conn.prepareStatement(updateDepartmentQuery);
                preparedStatement.setString(1, selectedCourse.getCourseName());
                preparedStatement.setString(2, newCourseName);
                preparedStatement.setString(3, getDepartment());

                int updatedDepartmentRows = preparedStatement.executeUpdate();

                if (updatedDepartmentRows > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Department courses updated successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to update department courses.");
                }


                String updateTeacherQuery = "UPDATE TEACHER SET COURSE = ? WHERE NAME = ?";
                preparedStatement = conn.prepareStatement(updateTeacherQuery);
                preparedStatement.setString(1, newCourseName);
                preparedStatement.setString(2, newTeacher);

                int updatedTeacherRows = preparedStatement.executeUpdate();

                if (updatedTeacherRows > 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher's course updated successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Failed to update teacher's course.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to update course.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while updating course: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    protected void initialize(){
        NameColumn.setCellValueFactory(new PropertyValueFactory<>("CourseName"));
        CodeColumn.setCellValueFactory(new PropertyValueFactory<>("CourseCode"));

        TeacherColumn.setCellValueFactory(cellData -> {
            TEACHER teacher = cellData.getValue().getCourseTeacher();
            StringProperty nameProperty = new SimpleStringProperty(teacher.getName());
            return nameProperty;
        });

        CreditColumn.setCellValueFactory(new PropertyValueFactory<>("CreditHours"));
        DepartmentColumn.setCellValueFactory(new PropertyValueFactory<>("Department"));

        loadCoursesFromDatabase();

        CoursesTable.setItems(courseList);
        cbCreditHours.getItems().addAll(1, 2, 3);
        loadTeachersFromDataBase();
        List<String> teacherNames = new ArrayList<>();
        for (TEACHER teacher : TeacherList) {
            teacherNames.add(teacher.getName());
        }
        cbCourseTeacher.setItems(FXCollections.observableArrayList(teacherNames));
    }

    private void loadTeachersFromDataBase() {
        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM TEACHER");
            ResultSet rs = preparedStatement.executeQuery();

            List<TEACHER> teachers = new ArrayList<>();

            while(rs.next()) {
                Courses course = new Courses();
                course.setCourseName(rs.getString("COURSE"));
                TEACHER teacher = new TEACHER(
                        rs.getString("ID"),
                        rs.getString("NAME"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"),
                        rs.getString("DEPARTMENT_NAME")
                );
                teacher.setCourse(course);

                teachers.add(teacher);
            }
            TeacherList.addAll(teachers);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while loading teachers: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadCoursesFromDatabase() {
        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            Statement stmt = conn.createStatement();
            String query = "SELECT * FROM COURSES";
            ResultSet rs = stmt.executeQuery(query);

            List<Courses> courses = new ArrayList<>();
            while (rs.next()) {
                TEACHER teacher = new TEACHER();
                teacher.setName(rs.getString("Teacher"));
                Courses course = new Courses(
                        rs.getString("CourseName"),
                        rs.getString("CourseCode"),
                        teacher,
                        rs.getInt("CreditHours"),
                        rs.getString("DEPARTMENT_NAME")
                );
                courses.add(course);
            }
            courseList.addAll(courses);

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while loading courses: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String Department;

    public void setDepartment(String Department) {
        this.Department = Department;
    }

    public String getDepartment() {
        return this.Department;
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void clearFields() {
        tfCourseName.clear();
        tfCourseCode.clear();
        cbCourseTeacher.getSelectionModel().clearSelection();
        cbCreditHours.getSelectionModel().clearSelection();
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
    }
}
