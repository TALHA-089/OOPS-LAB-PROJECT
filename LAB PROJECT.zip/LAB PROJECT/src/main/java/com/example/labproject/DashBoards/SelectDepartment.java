package com.example.labproject.DashBoards;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class SelectDepartment {

    @FXML
    private Button btnSelect;

    @FXML
    private Button btnSignOut;

    @FXML
    private ComboBox<String> cbDepartment;

    @FXML
    private Button btnNew;

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";


    @FXML
    protected void SignOutAdmin() throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setTitle("SIGN OUT!");
        alert.setContentText("Are you Sure you want to Sign out?");

        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            Stage stage = (Stage) btnSignOut.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/University.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 450);
            stage.setTitle("WELCOME!");
            stage.setMinWidth(600);
            stage.setMinHeight(450);
            stage.setMaxWidth(600);
            stage.setMaxHeight(450);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    protected void DepartmentSelected() throws IOException {
        String Department = cbDepartment.getValue();

        if(Department != null){
            Stage stage = (Stage) btnSelect.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
            Scene scene = new Scene(fxmlLoader.load(),360,550);
            AdminDashBoard controller = fxmlLoader.getController();
            controller.setDepartment(Department);
            stage.setScene(scene);
            stage.setTitle("ADMIN DASHBOARD");
            stage.setMaxHeight(550);
            stage.setMaxWidth(360);
            stage.setMinWidth(360);
            stage.setMinHeight(550);
            stage.show();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR!");
            alert.setHeaderText(null);
            alert.setContentText("Please Choose a Department First!");
            alert.showAndWait();
        }
    }

    @FXML
    void AddNewDepartment() throws IOException {
        Stage stage = (Stage) btnNew.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Department/NewDepartment.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),400,450);
        stage.setScene(scene);
        stage.setMinHeight(450);
        stage.setMinWidth(400);
        stage.setMaxWidth(400);
        stage.setMaxHeight(450);
        stage.show();
    }

    @FXML
    protected void initialize(){
        ObservableList<String> departments = FXCollections.observableArrayList();
        try (Connection connection = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD);
             PreparedStatement stmt = connection.prepareStatement("SELECT DEPARTMENT_NAME FROM DEPARTMENTS");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                departments.add(rs.getString("DEPARTMENT_NAME"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
           Alert alert = new Alert(Alert.AlertType.ERROR);
           alert.setTitle("Database Error");
           alert.setHeaderText(null);
           alert.setContentText("Failed to fetch days from the database.");
           alert.showAndWait();
        }
        cbDepartment.setItems(departments);
    }
}
