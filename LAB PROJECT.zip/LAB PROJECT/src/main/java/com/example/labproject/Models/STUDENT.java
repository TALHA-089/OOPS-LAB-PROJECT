package com.example.labproject.Models;

import java.util.ArrayList;
import java.util.List;

public class STUDENT extends USER {

    private String Department;
    private List<Courses> StudentCourses;
    private Classes Classes;
    private String Semester;

    public STUDENT() {
        super();
        this.StudentCourses = new ArrayList<>();
    }

    public STUDENT(String id, String name, String email, String password, String department, String semester) {
        super(id, name, email, password);
        this.Department = department;
        this.Semester = semester;
        this.StudentCourses = new ArrayList<>();
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        this.Department = department;
    }

    public List<Courses> getStudentCourses() {
        return StudentCourses;
    }

    public void setStudentCourses(List<Courses> studentCourses) {
        this.StudentCourses = studentCourses;
    }

    public Classes getClasses() {
        return Classes;
    }

    public void setClasses(Classes classes) {
        this.Classes = classes;
    }

    public String getSemester() {
        return Semester;
    }

    public void setSemester(String semester) {
        this.Semester = semester;
    }

    public void addCourse(Courses course) {
        this.StudentCourses.add(course);
    }

    public void removeCourse(Courses course) {
        this.StudentCourses.remove(course);
    }

    @Override
    public String toString() {
        return "STUDENT{" +
                "Department='" + Department + '\'' +
                ", StudentCourses=" + StudentCourses +
                ", Classes=" + Classes +
                ", Semester='" + Semester + '\'' +
                ", ID='" + getID() + '\'' +
                ", Name='" + getName() + '\'' +
                ", Email='" + getEmail() + '\'' +
                '}';
    }
}
