package com.example.labproject.DashBoards.Admin;

import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Pair;

import java.io.IOException;
import java.sql.*;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NewDepartmentController {

    @FXML
    private Button btnBack;

    @FXML
    private Button btnAdd;

    @FXML
    private ComboBox<String> cbCampus;

    @FXML
    private ComboBox<String> cbBlock;

    @FXML
    private TextField tfDepartmentName;

    private static final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Talha@786";
    private static final Logger LOGGER = Logger.getLogger(NewDepartmentController.class.getName());

    @FXML
    protected void initialize() {
        cbBlock.setItems(FXCollections.observableArrayList("JOHAR", "JINNAH", "IQBAL"));
        cbCampus.setItems(FXCollections.observableArrayList("H-11", "E-8"));

        btnAdd.setOnAction(e -> showUserVerificationDialog());
    }

    @FXML
    protected void Back() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/SelectDepartment.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 350, 400);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(350);
        stage.setMinHeight(400);
        stage.setMaxWidth(350);
        stage.setMaxHeight(400);
        stage.setScene(scene);
        stage.show();
    }

    private void AddNewDepartment(String name,String campus,String block ) {

        String sql = "INSERT INTO DEPARTMENTS (DEPARTMENT_NAME, TEACHERS, COURSES, ROOMS, STUDENTS, CLASSES, Campus, Block) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            stmt.setString(2, null);
            stmt.setString(3, null);
            stmt.setString(4, null);
            stmt.setString(5, null);
            stmt.setString(6, null);
            stmt.setString(7, campus);
            stmt.setString(8, block);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                showAlert(Alert.AlertType.INFORMATION, "SUCCESS", "Department added successfully!");
                tfDepartmentName.clear();
                cbCampus.setValue(null);
                cbBlock.setValue(null);

                Stage stage = (Stage) btnAdd.getScene().getWindow();
                FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/SelectDepartment.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 350, 400);
                stage.setTitle("WELCOME!");
                stage.setMinWidth(350);
                stage.setMinHeight(400);
                stage.setMaxWidth(350);
                stage.setMaxHeight(400);
                stage.setScene(scene);
                stage.show();
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to add the department.", e);
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to add the department. Please try again.");
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to load the scene.", e);
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Failed to load the scene. Please try again.");
        }
    }

    private boolean isDepartNameUnique(String name) {
        String sql = "SELECT COUNT(*) FROM DEPARTMENTS WHERE DEPARTMENT_NAME = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, name);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error checking department name uniqueness.", e);
        }
        return false;
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void showUserVerificationDialog() {

        String campus = cbCampus.getValue();
        String block = cbBlock.getValue();
        String name = tfDepartmentName.getText();

        if (campus == null || block == null || name.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Please fill out all the fields.");
            return;
        }

        if (!isDepartNameUnique(name)) {
            showAlert(Alert.AlertType.ERROR, "ERROR!", "Department name already exists.");
            return;
        }


        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Admin Verification");
        dialog.setHeaderText("Please enter your Username and Password");

        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Username");
        PasswordField password = new PasswordField();
        password.setPromptText("Password");

        grid.add(new Label("Username:"), 0, 0);
        grid.add(username, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(password, 1, 1);

        dialog.getDialogPane().setContent(grid);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == ButtonType.OK) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            String user = usernamePassword.getKey();
            String pass = usernamePassword.getValue();

            if (verifyUser(user, pass)) {
                AddNewDepartment(name,campus,block);
            } else {
                showAlert(Alert.AlertType.ERROR, "ERROR!", "Admin verification failed.");
            }
        });
    }

    private boolean verifyUser(String username, String password) {
        String query = "SELECT PASSWORD FROM ADMIN WHERE USERNAME = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    String dbPassword = resultSet.getString("PASSWORD");
                    return password.equals(dbPassword);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error verifying user", e);
        }
        return false;
    }
}
