package com.example.labproject.DashBoards.Student.Profile;

import com.example.labproject.DashBoards.Student.StudentDashBoard;
import com.example.labproject.Models.Classes;
import com.example.labproject.Models.STUDENT;
import com.example.labproject.University;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProfileController {

    public STUDENT student = new STUDENT();
    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    private Label NameLabel;
    @FXML
    private Label IDLabel;
    @FXML
    private Label EmailLabel;
    @FXML
    private Label PasswordLabel;
    @FXML
    private Label ClassLabel;
    @FXML
    private Label DepartmentLabel;
    @FXML
    private Label SemesterLabel;

    @FXML
    private ImageView Back;

    public void loadStudentInfo(String enrollment){
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD)){

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM STUDENT WHERE ID = ?");
            preparedStatement.setString(1,enrollment);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                student.setID(enrollment);
                student.setName(resultSet.getString("NAME"));
                student.setEmail(resultSet.getString("EMAIL"));
                student.setPassword(resultSet.getString("PASSWORD"));
                student.setSemester(String.valueOf(resultSet.getInt("Semester")));
                student.setDepartment(resultSet.getString("DEPARTMENT_NAME"));
                Classes classes = new Classes();
                classes.setClassID(resultSet.getString("Class"));
                student.setClasses(classes);

                initializeStudentinfo(student);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initializeStudentinfo(STUDENT student) {
        IDLabel.setText(student.getID());
        NameLabel.setText(student.getName());
        EmailLabel.setText(student.getEmail());
        PasswordLabel.setText(student.getPassword());
        DepartmentLabel.setText(student.getDepartment());
        SemesterLabel.setText(student.getSemester());
        ClassLabel.setText(student.getClasses().getClassID());
    }

    @FXML
    protected void Exit() throws IOException {
        Stage stage = (Stage) Back.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 300, 350);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(300);
        stage.setMinHeight(350);
        stage.setMaxWidth(300);
        stage.setMaxHeight(350);
        stage.setScene(scene);
        StudentDashBoard controller = fxmlLoader.getController();
        controller.GlobalStudent.setID(student.getID());
        stage.show();
    }
}
