package com.example.labproject.DashBoards.Admin.TimeTable;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.Courses;
import com.example.labproject.Models.Room;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.Models.TimeTableEntry;
import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.*;

public class TimeTableController {
    private String Department;

    public void setDepartment(String department) {
        this.Department = department;
    }

    public String getDepartment(){
        return this.Department;
    }

    private ObservableList<Courses> courseList = FXCollections.observableArrayList();
    private ObservableList<Room> roomList = FXCollections.observableArrayList();
    private ObservableList<TimeTableEntry> timeTableData = FXCollections.observableArrayList();

    @FXML
    private Button btnGoBack;

    @FXML
    private TableView<TimeTableEntry> TimeTable;
    @FXML
    private TableColumn<TimeTableEntry, String> courseColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> teacherColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> dayColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> timeSlotColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> roomColumn;

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    protected void back() throws IOException {
        Stage stage = (Stage) btnGoBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 360, 550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.show();
    }

    @FXML
    protected void generateTimetable() {

        timeTableData.clear();

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String deleteQuery = "DELETE FROM " + Department + "_TimeTable";
            PreparedStatement deleteStatement = conn.prepareStatement(deleteQuery);
            deleteStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String[] days = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
        String[] timeSlots = {"08:00-10:00", "10:00-12:00", "12:00-14:00", "14:00-16:00", "16:00-18:00"};

        Map<String, Map<String, String>> roomSchedule = initializeRoomSchedule();

        for (Courses course : courseList) {
            boolean scheduled = false;
            while (!scheduled) {

                List<String> shuffledDays = new ArrayList<>(List.of(days));
                List<String> shuffledTimeSlots = new ArrayList<>(List.of(timeSlots));
                Collections.shuffle(shuffledDays);
                Collections.shuffle(shuffledTimeSlots);

                for (String day : shuffledDays) {
                    for (String timeSlot : shuffledTimeSlots) {
                        for (Room room : roomList) {
                            if (!roomSchedule.get(room.getRoomID()).containsKey(day)) {
                                TimeTableEntry entry = new TimeTableEntry(
                                        course.getCourseName(),
                                        course.getCourseTeacher().getName(),
                                        day,
                                        timeSlot,
                                        room.getRoomID()
                                );
                                timeTableData.add(entry);
                                roomSchedule.get(room.getRoomID()).put(day, timeSlot);

                                scheduled = true;
                                break;
                            }
                        }
                        if (scheduled) {
                            break;
                        }
                    }
                    if (scheduled) {
                        break;
                    }
                }
            }
        }

        saveTimeTableToDatabase();
        initializeTableView();
    }


    private Map<String, Map<String, String>> initializeRoomSchedule() {
        Map<String, Map<String, String>> roomSchedule = new HashMap<>();
        for (Room room : roomList) {
            roomSchedule.put(room.getRoomID(), new HashMap<>());
        }
        return roomSchedule;
    }

    private void saveTimeTableToDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {

            String createTableQuery = "CREATE TABLE IF NOT EXISTS " + Department + "_TimeTable (" +
                    "Course VARCHAR(255), " +
                    "Teacher VARCHAR(255), " +
                    "Day VARCHAR(255), " +
                    "TimeSlot VARCHAR(255), " +
                    "Room VARCHAR(255))";
            PreparedStatement createStatement = conn.prepareStatement(createTableQuery);
            createStatement.executeUpdate();

            String insertQuery = "INSERT INTO " + Department + "_TimeTable (Course, Teacher, Day, TimeSlot, Room) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertStatement = conn.prepareStatement(insertQuery);
            for (TimeTableEntry entry : timeTableData) {
                insertStatement.setString(1, entry.getCourse());
                insertStatement.setString(2, entry.getTeacher());
                insertStatement.setString(3, entry.getDay());
                insertStatement.setString(4, entry.getTimeSlot());
                insertStatement.setString(5, entry.getRoom());
                insertStatement.addBatch();
            }
            insertStatement.executeBatch();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void initialize() {
        loadRoomData(Department);
        loadCourseData(Department);
    }

    private void initializeTableView() {
        courseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        teacherColumn.setCellValueFactory(new PropertyValueFactory<>("teacher"));
        dayColumn.setCellValueFactory(new PropertyValueFactory<>("day"));
        timeSlotColumn.setCellValueFactory(new PropertyValueFactory<>("timeSlot"));
        roomColumn.setCellValueFactory(new PropertyValueFactory<>("room"));
        TimeTable.setItems(timeTableData);
    }

    public void loadCourseData(String department) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM COURSES WHERE DEPARTMENT_NAME = ?");
            preparedStatement.setString(1, department);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Courses course = new Courses();
                TEACHER teacher = new TEACHER();
                course.setCourseName(resultSet.getString("CourseName"));
                course.setCourseCode(resultSet.getString("CourseCode"));
                teacher.setName(resultSet.getString("Teacher"));
                course.setCourseTeacher(teacher);
                course.setCreditHours(resultSet.getInt("CreditHours"));
                course.setDepartment(department);

                courseList.add(course);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void loadRoomData(String department) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM ROOMS WHERE DEPARTMENT = ?");
            preparedStatement.setString(1, department);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Room room = new Room();
                room.setRoomID(resultSet.getString("ROOMID"));
                room.setFloor(resultSet.getInt("Floor"));
                room.setRoomNo(resultSet.getInt("RoomNo"));
                room.setCapacity(resultSet.getInt("CAPACITY"));
                room.setDepartment(department);

                roomList.add(room);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
