package com.example.labproject.Models;

public class Courses {

    private String CourseName;
    private String CourseCode;
    private TEACHER CourseTeacher;
    private int CreditHours;
    private String Department;

    public Courses(String CourseName, String CourseCode, TEACHER CourseTeacher, int CreditHours, String Department) {
        this.CourseName = CourseName;
        this.CourseCode = CourseCode;
        this.CourseTeacher = CourseTeacher;
        this.CreditHours = CreditHours;
        this.Department = Department;
    }

    public Courses() {
    }

    public String getCourseName() {
        return CourseName;
    }

    public void setCourseName(String courseName) {
        CourseName = courseName;
    }

    public String getCourseCode() {
        return CourseCode;
    }

    public void setCourseCode(String courseCode) {
        CourseCode = courseCode;
    }

    public TEACHER getCourseTeacher() {
        return CourseTeacher;
    }

    public void setCourseTeacher(TEACHER courseTeacher) {
        CourseTeacher = courseTeacher;
    }

    public int getCreditHours() {
        return CreditHours;
    }

    public void setCreditHours(int creditHours) {
        CreditHours = creditHours;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    @Override
    public String toString() {
        return STR."Courses{CourseName='\{CourseName}\{'\''}, CourseCode='\{CourseCode}\{'\''}, CourseTeacher=\{CourseTeacher}, CreditHours=\{CreditHours}, Department='\{Department}\{'\''}\{'}'}";
    }
}
