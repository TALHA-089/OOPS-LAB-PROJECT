package com.example.labproject.Models;

public class TimeTableEntry {
    private String course;
    private String teacher;
    private String day;
    private String timeSlot;
    private String room;

    public TimeTableEntry(String course, String teacher, String day, String timeSlot, String room) {
        this.course = course;
        this.teacher = teacher;
        this.day = day;
        this.timeSlot = timeSlot;
        this.room = room;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getTeacher() {
        return teacher;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }
}
