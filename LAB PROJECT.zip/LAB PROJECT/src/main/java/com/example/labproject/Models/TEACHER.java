package com.example.labproject.Models;

public class TEACHER extends USER {
    private Courses Course;
    private String Department;

    public void setDepartment(String Department){
        this.Department = Department;
    }

    public String getDepartment(){
        return this.Department;
    }
    public void setCourse(Courses course){
        this.Course = course;
    }

    public Courses getCourse(){
        return this.Course;
    }

    public TEACHER() {
        super();
    }

    public TEACHER(String id, String name, String email, String password,String Department) {
        super(id, name, email, password);
        this.Department = Department;

    }
}

