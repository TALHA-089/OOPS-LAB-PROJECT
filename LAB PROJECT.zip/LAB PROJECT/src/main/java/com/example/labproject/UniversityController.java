package com.example.labproject;

import com.example.labproject.DashBoards.Student.StudentDashBoard;
import com.example.labproject.DashBoards.Teacher.TeacherDashBoard;
import com.example.labproject.Models.TEACHER;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class UniversityController implements Initializable {

    @FXML
    private Label LabelName;

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnExit;

    @FXML
    private TextField tfUserName;

    @FXML
    private PasswordField pfPassword;

    @FXML
    private ComboBox<String> cbUserType;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cbUserType.getItems().addAll("ADMIN", "STUDENT", "TEACHER");

        cbUserType.valueProperty().addListener((observable, oldValue, newValue) -> {
            if ("ADMIN".equals(newValue)) {
                LabelName.setText("USERNAME");
            } else if ("STUDENT".equals(newValue)) {
                LabelName.setText("ENROLLMENT");
            } else if ("TEACHER".equals(newValue)) {
                LabelName.setText("TEACHER ID");
            }
        });
    }

    @FXML
    protected void LoginUser() {
        String ID = tfUserName.getText();
        String Password = pfPassword.getText();

        if (ID.isEmpty() || Password.isEmpty() || ID.isBlank() || Password.isBlank()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("EMPTY FIELDS!");
            alert.setHeaderText(null);
            alert.setContentText("PLEASE FILL OUT ALL THE FIELDS");
            alert.showAndWait();
            return;
        }

        final String DB_URL = "jdbc:mysql://localhost:3306/LABPROJECT?serverTimezone=UTC";
        final String USERNAME = "root";
        final String PASSWORD = "Talha@786";

        String userType = cbUserType.getValue();

        if (userType == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("NO USER TYPE SELECTED");
            alert.setHeaderText(null);
            alert.setContentText("PLEASE SELECT A USER TYPE");
            alert.showAndWait();
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "";
            String Type = "";
            if ("ADMIN".equals(userType)) {
                query = "SELECT USERNAME, PASSWORD FROM ADMIN WHERE USERNAME = ?";
                Type = "ADMIN";
            } else if ("STUDENT".equals(userType)) {
                query = "SELECT ID, PASSWORD FROM STUDENT WHERE ID = ?";
                Type = "STUDENT";
            } else if ("TEACHER".equals(userType)) {
                query = "SELECT ID, PASSWORD FROM TEACHER WHERE ID = ?";
                Type = "TEACHER";
            }

            try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                preparedStatement.setString(1, ID);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        String dbUserName = resultSet.getString(1);
                        String dbPassword = resultSet.getString(2);

                        if (Password.equals(dbPassword) && ID.equals(dbUserName)) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("LOGIN SUCCESS");
                            alert.setHeaderText(null);
                            alert.setContentText("WELCOME " + dbUserName);
                            alert.showAndWait();

                            if(Type.equals("ADMIN")){
                                Stage stage = (Stage) btnLogin.getScene().getWindow();
                                FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/SelectDepartment.fxml"));
                                Scene scene = new Scene(fxmlLoader.load(), 350, 400);
                                stage.setTitle("WELCOME!");
                                stage.setMinWidth(350);
                                stage.setMinHeight(400);
                                stage.setMaxWidth(350);
                                stage.setMaxHeight(400);
                                stage.setScene(scene);
                                stage.show();
                            } else if (Type.equals("STUDENT")) {

                                Stage stage = (Stage) btnLogin.getScene().getWindow();
                                FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/StudentDashBoard.fxml"));
                                Scene scene = new Scene(fxmlLoader.load(), 300, 350);
                                stage.setTitle("WELCOME!");
                                stage.setMinWidth(300);
                                stage.setMinHeight(350);
                                stage.setMaxWidth(300);
                                stage.setMaxHeight(350);
                                stage.setScene(scene);
                                StudentDashBoard controller = fxmlLoader.getController();
                                controller.GlobalStudent.setID(dbUserName);
                                stage.show();

                            } else if (Type.equals("TEACHER")) {

                                Stage stage = (Stage) btnLogin.getScene().getWindow();
                                FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
                                Scene scene = new Scene(fxmlLoader.load(), 300, 350);
                                stage.setTitle("WELCOME!");
                                stage.setMinWidth(300);
                                stage.setMinHeight(350);
                                stage.setMaxWidth(300);
                                stage.setMaxHeight(350);
                                stage.setScene(scene);
                                TeacherDashBoard controller = fxmlLoader.getController();
                                controller.GlobalTeacher.setID(dbUserName);
                                stage.show();
                            }


                        } else {
                            Alert alert = new Alert(Alert.AlertType.ERROR);
                            alert.setTitle("LOGIN UNSUCCESSFUL");
                            alert.setHeaderText(null);
                            alert.setContentText("INVALID CREDENTIALS!");
                            alert.showAndWait();
                        }
                    } else {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("LOGIN UNSUCCESSFUL");
                        alert.setHeaderText(null);
                        alert.setContentText("USER NOT FOUND!");
                        alert.showAndWait();
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void ExitApplication() {
        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmationAlert.setTitle("Exit Confirmation");
        confirmationAlert.setHeaderText(null);
        confirmationAlert.setContentText("Are you sure you want to exit the application?");

        ButtonType result = confirmationAlert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            Stage stage = (Stage) btnExit.getScene().getWindow();
            stage.close();
        }
    }
}
