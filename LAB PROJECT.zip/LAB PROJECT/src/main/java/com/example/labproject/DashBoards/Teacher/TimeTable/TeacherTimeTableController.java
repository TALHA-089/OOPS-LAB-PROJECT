package com.example.labproject.DashBoards.Teacher.TimeTable;

import com.example.labproject.DashBoards.Teacher.TeacherDashBoard;
import com.example.labproject.Models.Classes;
import com.example.labproject.Models.Courses;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.Models.TimeTableEntry;
import com.example.labproject.University;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TeacherTimeTableController {

    public TEACHER teacher = new TEACHER();

    @FXML
    private Label DepartmentLabel;
    @FXML
    private Button btnBack;
    @FXML
    private TableView<TimeTableEntry> TimeTable;
    @FXML
    private TableColumn<TimeTableEntry, String> CourseColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> TeacherColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> DayColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> TimeSlotColumn;
    @FXML
    private TableColumn<TimeTableEntry, String> RoomColumn;

    final String DB_URL = "jdbc:mysql://localhost:3306/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    private ObservableList<TimeTableEntry> timeTableData = FXCollections.observableArrayList();

    public void loadTeacherInfo(String ID) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM TEACHER WHERE ID = ?");
            preparedStatement.setString(1, ID);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                teacher.setID(ID);
                teacher.setName(resultSet.getString("NAME"));
                teacher.setEmail(resultSet.getString("EMAIL"));
                teacher.setPassword(resultSet.getString("PASSWORD"));
                teacher.setDepartment(resultSet.getString("DEPARTMENT_NAME"));
                Courses courses = new Courses();
                courses.setCourseName(resultSet.getString("COURSE"));
                teacher.setCourse(courses);
                DepartmentLabel.setText("DEPARTMENT : " + teacher.getDepartment());
                loadTimeTableData();
                initializeTableView();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadTimeTableData() {

        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD)) {

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM " + teacher.getDepartment()+"_TimeTable WHERE Teacher = ?");
            preparedStatement.setString(1,teacher.getName());
            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                String courseName = resultSet.getString("Course");
                String teacher = resultSet.getString("Teacher");
                String day = resultSet.getString("Day");
                String timeSlot = resultSet.getString("TimeSlot");
                String room = resultSet.getString("Room");
                TimeTableEntry timeTableEntry = new TimeTableEntry(courseName, teacher, day, timeSlot, room);
                timeTableData.add(timeTableEntry);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initializeTableView() {
        CourseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        TeacherColumn.setCellValueFactory(new PropertyValueFactory<>("teacher"));
        DayColumn.setCellValueFactory(new PropertyValueFactory<>("day"));
        TimeSlotColumn.setCellValueFactory(new PropertyValueFactory<>("timeSlot"));
        RoomColumn.setCellValueFactory(new PropertyValueFactory<>("room"));
        TimeTable.setItems(timeTableData);
    }


    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 300, 350);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(300);
        stage.setMinHeight(350);
        stage.setMaxWidth(300);
        stage.setMaxHeight(350);
        stage.setScene(scene);
        TeacherDashBoard controller = fxmlLoader.getController();
        controller.GlobalTeacher.setID(teacher.getID());
        stage.show();
    }

}
