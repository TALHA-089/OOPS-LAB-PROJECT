package com.example.labproject.Models;

import java.util.ArrayList;
import java.util.List;

public class Classes {

    private List<STUDENT> studentsList;
    private List<Courses> coursesList;
    private String semester;
    private String Department;
    private String ClassID;

    public Classes() {
        this.studentsList = new ArrayList<>();
        this.coursesList = new ArrayList<>();
    }

    public Classes(String semester, String Department) {
        this.semester = semester;
        this.Department = Department;
        GenerateClassID();
        this.studentsList = new ArrayList<>();
        this.coursesList = new ArrayList<>();
    }

    public List<STUDENT> getStudentsList() {
        return studentsList;
    }

    public void setStudentsList(List<STUDENT> studentsList) {
        this.studentsList = studentsList;
    }
    public void setCoursesList(List<Courses> coursesList){
        this.coursesList = coursesList;
    }

    public List<Courses> getCoursesList(){
        return this.coursesList;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

//    public void addStudent(STUDENT student) {
//        this.studentsList.add(student);
//    }
//
//    public void removeStudent(STUDENT student) {
//        this.studentsList.remove(student);
//    }


//    public STUDENT getStudentById(String studentId) {
//        for (STUDENT student : studentsList) {
//            if (student.getID().equals(studentId)) {
//                return student;
//            }
//        }
//        return null;
//    }

    public int getStudentCount() {
        return this.studentsList.size();
    }

    public void setDepartment(String Department){
        this.Department = Department;
    }

    public String getDepartment(){
        return this.Department;
    }

    public void GenerateClassID(){
        this.ClassID = this.getDepartment() + "-" + this.getSemester() + "A";
    }

    public void setClassID(String ClassID){
        this.ClassID = ClassID;
    }

    public String getClassID(){
        return this.ClassID;
    }

    @Override
    public String toString() {
        return "Classes{" +
                "studentsList=" + studentsList +
                ", semester='" + semester + '\'' +
                '}';
    }
}
