package com.example.labproject.DashBoards.Admin.Students;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.Classes;
import com.example.labproject.Models.STUDENT;
import com.example.labproject.University;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static javafx.scene.control.Alert.AlertType.ERROR;
import static javafx.scene.control.Alert.AlertType.INFORMATION;

public class StudentsController {

    public String Department;

    public void setDepartment(String department) {
        this.Department = department;
    }

    public String getDepartment() {
        return this.Department;
    }

    @FXML
    private Button btnBack;

    @FXML
    private TextField tfStudentName;
    @FXML
    private TextField tfStudentID;
    @FXML
    private TextField tfStudentEmail;
    @FXML
    private PasswordField pfStudentPassword;
    @FXML
    private ComboBox<Integer> cbStudentSemester;
    @FXML
    private ComboBox<String> cbStudentClass;

    @FXML
    private TableView<STUDENT> StudentsTable;

    @FXML
    private TableColumn<STUDENT, String> IDColumn;
    @FXML
    private TableColumn<STUDENT, String> NameColumn;
    @FXML
    private TableColumn<STUDENT, String> EmailColumn;
    @FXML
    private TableColumn<STUDENT, Integer> SemesterColumn;
    @FXML
    private TableColumn<STUDENT, String> ClassColumn;

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    private ObservableList<String> classIDs = FXCollections.observableArrayList();
    private ObservableList<STUDENT> studentList = FXCollections.observableArrayList();

    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),360,550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.show();
    }

    @FXML
    protected void AddStudent() {
        String id = tfStudentID.getText();
        String name = tfStudentName.getText();
        String email = tfStudentEmail.getText();
        String password = pfStudentPassword.getText();
        Integer semester = cbStudentSemester.getValue();
        String classID = cbStudentClass.getValue();

        if (id.isEmpty() || name.isEmpty() || password.isEmpty() || email.isEmpty() || semester == null || classID == null) {
            showAlert(ERROR,"Error", "Please fill all fields!");
            return;
        }
        if(!isStudentUnique(id)){
            showAlert(ERROR,"Error", "Student ID already exists");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "INSERT INTO STUDENT (ID, NAME, EMAIL, PASSWORD, SEMESTER, CLASS, DEPARTMENT_NAME) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4,password);
            preparedStatement.setInt(5, semester);
            preparedStatement.setString(6, classID);
            preparedStatement.setString(7, this.getDepartment());

            preparedStatement.executeUpdate();

            Classes studentClass = new Classes();
            studentClass.setClassID(classID);
            studentClass.setSemester(String.valueOf(semester));

            STUDENT student = new STUDENT(id, name, email, password, this.getDepartment(), String.valueOf(semester));
            student.setClasses(studentClass);
            studentList.add(student);

            clearForm();
            showAlert(INFORMATION,"Success", "Student added successfully!");

            String updateDepartmentQuery = "UPDATE DEPARTMENTS SET STUDENTS = CONCAT(STUDENTS, ?) WHERE DEPARTMENT_NAME = ?";
            preparedStatement = conn.prepareStatement(updateDepartmentQuery);
            preparedStatement.setString(1, ", " + name);
            preparedStatement.setString(2, getDepartment());

            int updatedDepartmentRows = preparedStatement.executeUpdate();

            if (updatedDepartmentRows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "Success", "Department Students Updated Successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to Update Department Students.");
            }

            String updateClassesQuery = "UPDATE CLASSES SET STUDENTS = CONCAT(IFNULL(STUDENTS, ''), ?) WHERE CLASSID = ?";
            preparedStatement = conn.prepareStatement(updateClassesQuery);
            preparedStatement.setString(1, (", " + name).trim());
            preparedStatement.setString(2, classID);


            int updateClassesRows = preparedStatement.executeUpdate();

            if(updateClassesRows > 0){
                showAlert(INFORMATION, "Success","Classes Students Updated Successfully");
            }else{
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to Update Classes Students.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(ERROR,"Error", "Error adding student.");
        }
    }

    private boolean isStudentUnique(String id) {
        String sql = "SELECT COUNT(*) FROM STUDENT WHERE ID = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, id);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    return count == 0;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @FXML
    protected void EditStudent() {
        STUDENT selectedStudent = StudentsTable.getSelectionModel().getSelectedItem();
        if (selectedStudent == null) {
            showAlert(ERROR,"Error", "Please select a student to edit.");
            return;
        }

        String oldID = selectedStudent.getID();
        String oldName = selectedStudent.getName();

        String id = tfStudentID.getText();
        String name = tfStudentName.getText();
        String email = tfStudentEmail.getText();
        String password = pfStudentPassword.getText();
        Integer semester = cbStudentSemester.getValue();
        String classID = cbStudentClass.getValue();

        if (id.isEmpty() || name.isEmpty() || email.isEmpty() || password.isEmpty() || semester == null || classID == null) {
            showAlert(ERROR,"Error", "Please fill all fields!");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "UPDATE STUDENT SET ID=?, NAME=?, EMAIL=?, PASSWORD=?, SEMESTER=?, CLASS=?, DEPARTMENT_NAME=? WHERE ID=?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3,email);
            preparedStatement.setString(4,password);
            preparedStatement.setInt(5, semester);
            preparedStatement.setString(6, classID);
            preparedStatement.setString(7, this.getDepartment());
            preparedStatement.setString(8, oldID);

            preparedStatement.executeUpdate();

            selectedStudent.setID(id);
            selectedStudent.setName(name);
            selectedStudent.setEmail(email);
            selectedStudent.setPassword(password);
            selectedStudent.setSemester(String.valueOf(semester));
            Classes studentClass = new Classes();
            studentClass.setClassID(classID);
            studentClass.setSemester(String.valueOf(semester));
            selectedStudent.setClasses(studentClass);

            StudentsTable.refresh();
            clearForm();
            showAlert(INFORMATION,"Success", "Student updated successfully!");


            updateStudentNameInClasses(conn, oldName, name, classID);

            updateStudentNameInDepartments(conn, oldName, name, getDepartment());

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(ERROR,"Error", "Error updating student.");
        }
    }

    private void updateStudentNameInClasses(Connection conn, String oldName, String newName, String classID) throws SQLException {
        String selectClassQuery = "SELECT STUDENTS FROM CLASSES WHERE CLASSID = ?";
        PreparedStatement selectClassStatement = conn.prepareStatement(selectClassQuery);
        selectClassStatement.setString(1, classID);
        ResultSet resultSet = selectClassStatement.executeQuery();

        if (resultSet.next()) {
            String students = resultSet.getString("STUDENTS");
            List<String> studentNames = new ArrayList<>(Arrays.asList(students.split(", ")));

            for (int i = 0; i < studentNames.size(); i++) {
                if (studentNames.get(i).equals(oldName)) {
                    studentNames.set(i, newName);
                    break;
                }
            }

            String updatedStudentNames = String.join(", ", studentNames);

            String updateClassQuery = "UPDATE CLASSES SET STUDENTS = ? WHERE CLASSID = ?";
            PreparedStatement updateClassStatement = conn.prepareStatement(updateClassQuery);
            updateClassStatement.setString(1, updatedStudentNames);
            updateClassStatement.setString(2, classID);
            updateClassStatement.executeUpdate();
        }
    }

    private void updateStudentNameInDepartments(Connection conn, String oldName, String newName, String departmentName) throws SQLException {

        String selectDepartmentQuery = "SELECT STUDENTS FROM DEPARTMENTS WHERE DEPARTMENT_NAME = ?";
        PreparedStatement selectDepartmentStatement = conn.prepareStatement(selectDepartmentQuery);
        selectDepartmentStatement.setString(1, departmentName);
        ResultSet resultSet = selectDepartmentStatement.executeQuery();

        if (resultSet.next()) {
            String students = resultSet.getString("STUDENTS");
            List<String> studentNames = new ArrayList<>(Arrays.asList(students.split(", ")));


            for (int i = 0; i < studentNames.size(); i++) {
                if (studentNames.get(i).equals(oldName)) {
                    studentNames.set(i, newName);
                    break;
                }
            }

            String updatedStudentNames = String.join(", ", studentNames);

            String updateDepartmentQuery = "UPDATE DEPARTMENTS SET STUDENTS = ? WHERE DEPARTMENT_NAME = ?";
            PreparedStatement updateDepartmentStatement = conn.prepareStatement(updateDepartmentQuery);
            updateDepartmentStatement.setString(1, updatedStudentNames);
            updateDepartmentStatement.setString(2, departmentName);
            updateDepartmentStatement.executeUpdate();
        }
    }

    @FXML
    protected void RemoveStudent() {
        STUDENT selectedStudent = StudentsTable.getSelectionModel().getSelectedItem();
        if (selectedStudent == null) {
            showAlert(ERROR,"Error", "Please select a student to remove.");
            return;
        }

        String oldName = selectedStudent.getName();
        String classID = selectedStudent.getClasses().getClassID();

        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "DELETE FROM STUDENT WHERE ID=?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, selectedStudent.getID());

            preparedStatement.executeUpdate();

            String selectClassQuery = "SELECT STUDENTS FROM CLASSES WHERE CLASSID = ?";
            PreparedStatement selectClassStatement = conn.prepareStatement(selectClassQuery);
            selectClassStatement.setString(1, classID);
            ResultSet resultSet = selectClassStatement.executeQuery();

            if (resultSet.next()) {
                String students = resultSet.getString("STUDENTS");
                List<String> studentNames = new ArrayList<>(Arrays.asList(students.split(", ")));

                for (int i = 0; i < studentNames.size(); i++) {
                    if (studentNames.get(i).equals(oldName)) {
                        studentNames.remove(i);
                        break;
                    }
                }

                String updatedStudentNames = String.join(", ", studentNames);

                String updateClassQuery = "UPDATE CLASSES SET STUDENTS = ? WHERE CLASSID = ?";
                PreparedStatement updateClassStatement = conn.prepareStatement(updateClassQuery);
                updateClassStatement.setString(1, updatedStudentNames);
                updateClassStatement.setString(2, classID);
                updateClassStatement.executeUpdate();

                String selectDepartmentQuery = "SELECT STUDENTS FROM DEPARTMENTS WHERE DEPARTMENT_NAME = ?";

                PreparedStatement selectDepartmentStatement = conn.prepareStatement(selectDepartmentQuery);
                selectDepartmentStatement.setString(1, getDepartment());
                ResultSet newresultSet = selectDepartmentStatement.executeQuery();

                if (newresultSet.next()) {
                    String Students = resultSet.getString("STUDENTS");
                    List<String> StudentNames = new ArrayList<>(Arrays.asList(Students.split(", ")));

                    for (int i = 0; i < StudentNames.size(); i++) {
                        if (StudentNames.get(i).equals(oldName)) {
                            StudentNames.remove(i);
                            break;
                        }
                    }

                    String UpdatedStudentNames = String.join(", ", StudentNames);

                    String updateDepartmentQuery = "UPDATE DEPARTMENTS SET STUDENTS = ? WHERE DEPARTMENT_NAME = ?";
                    PreparedStatement updateDepartmentStatement = conn.prepareStatement(updateDepartmentQuery);
                    updateDepartmentStatement.setString(1, UpdatedStudentNames);
                    updateDepartmentStatement.setString(2, getDepartment());
                    updateDepartmentStatement.executeUpdate();
                }
                studentList.remove(selectedStudent);
                clearForm();
                showAlert(INFORMATION,"Success", "Student removed successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(ERROR,"Error", "Error removing student.");
        }
    }


    @FXML
    protected void initialize() {
        IDColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        NameColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        EmailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
        SemesterColumn.setCellValueFactory(new PropertyValueFactory<>("Semester"));
        ClassColumn.setCellValueFactory(cellData -> {
            Classes classes = cellData.getValue().getClasses();
            if (classes != null) {
                return new SimpleStringProperty(classes.getClassID());
            } else {
                return new SimpleStringProperty("");
            }
        });
        StudentsTable.setItems(studentList);
        cbStudentClass.setItems(classIDs);
        cbStudentSemester.getItems().addAll(1, 2, 3, 4, 5, 6, 7, 8);

        cbStudentSemester.valueProperty().addListener((obs, oldSemester, newSemester) -> {
            if (newSemester != null) {
                loadClassesForSemester(newSemester);
            }
        });
    }

    public void loadClassesFromDataBase(String department) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT CLASSID FROM CLASSES WHERE DEPARTMENT = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, department);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String ClassID = resultSet.getString("CLASSID");
                classIDs.add(ClassID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public void loadStudentsFromDatabase(String department) {
        classIDs.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            studentList.clear();

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM STUDENT WHERE DEPARTMENT_NAME = ?");
            preparedStatement.setString(1, department);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String id = resultSet.getString("ID");
                String name = resultSet.getString("NAME");
                String email = resultSet.getString("EMAIL");
                int semester = resultSet.getInt("SEMESTER");
                String classID = resultSet.getString("CLASS");

                Classes studentClass = new Classes();
                studentClass.setClassID(classID);
                studentClass.setSemester(String.valueOf(semester));

                STUDENT student = new STUDENT(id, name, email, null, this.getDepartment(), String.valueOf(semester));
                student.setClasses(studentClass);

                studentList.add(student);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    private void loadClassesForSemester(int semester) {
        classIDs.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD)) {
            String query = "SELECT CLASSID FROM CLASSES WHERE DEPARTMENT = ? AND SEMESTER = ?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString(1, getDepartment());
            preparedStatement.setInt(2, semester);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String ClassID = resultSet.getString("CLASSID");
                classIDs.add(ClassID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    private void clearForm() {
        tfStudentID.clear();
        tfStudentName.clear();
        tfStudentEmail.clear();
        cbStudentSemester.setValue(null);
        cbStudentClass.setValue(null);
        pfStudentPassword.clear();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
