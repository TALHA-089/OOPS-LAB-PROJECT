package com.example.labproject.DashBoards.Teacher;

import com.example.labproject.DashBoards.Student.Profile.ProfileController;
import com.example.labproject.DashBoards.Teacher.Profile.TeacherProfileController;
import com.example.labproject.DashBoards.Teacher.Students.SearchStudentController;
import com.example.labproject.DashBoards.Teacher.TimeTable.TeacherTimeTableController;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.University;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.TimeZone;

public class TeacherDashBoard {

    public TEACHER GlobalTeacher = new TEACHER();

    @FXML
    private Button btnSignOut;
    @FXML
    private Button btnProfile;
    @FXML
    private Button btnTimeTable;
    @FXML
    private Button btnStudents;

    @FXML
    protected void SignOut() throws IOException {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setTitle("SIGN OUT!");
        alert.setContentText("Are you Sure you want to Sign out?");

        ButtonType result = alert.showAndWait().orElse(ButtonType.CANCEL);

        if (result == ButtonType.OK) {
            Stage stage = (Stage) btnSignOut.getScene().getWindow();
            FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/University.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 450);
            stage.setTitle("WELCOME!");
            stage.setMinWidth(600);
            stage.setMinHeight(450);
            stage.setMaxWidth(600);
            stage.setMaxHeight(450);
            stage.setScene(scene);
            stage.show();
        }
    }

    @FXML
    protected void TeacherProfile() throws IOException {
        Stage stage = (Stage) btnProfile.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Teachers/Profile.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 550);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(600);
        stage.setMinHeight(550);
        stage.setMaxWidth(600);
        stage.setMaxHeight(550);
        stage.setScene(scene);
        TeacherProfileController controller = fxmlLoader.getController();
        controller.loadTeacherInfo(GlobalTeacher.getID());
        stage.show();
    }

    @FXML
    protected void Students() throws IOException {
        Stage stage = (Stage) btnStudents.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Teachers/SearchForStudents.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 550);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(600);
        stage.setMinHeight(550);
        stage.setMaxWidth(600);
        stage.setMaxHeight(550);
        stage.setScene(scene);
        SearchStudentController controller = fxmlLoader.getController();
        controller.teacher.setID(GlobalTeacher.getID());
        stage.show();
    }

    @FXML
    protected void TeacherTimeTable() throws IOException {
        Stage stage = (Stage) btnTimeTable.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/Teachers/TeacherTimeTable.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 450);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(600);
        stage.setMinHeight(450);
        stage.setMaxWidth(600);
        stage.setMaxHeight(450);
        stage.setScene(scene);
        TeacherTimeTableController controller = fxmlLoader.getController();
        controller.loadTeacherInfo(GlobalTeacher.getID());
        stage.show();
    }
}
