package com.example.labproject.Models;

public class USER {

    private String ID;
    private String Name;
    private String Email;
    private String Password;

    public USER(){}
    public USER(String id ,String name, String email, String password){

        this.ID = id;
        this.Name = name;
        this.Email = email;
        this.Password = password;

    }

    public void setID(String id){
        this.ID = id;
    }

    public String getID(){
        return this.ID;
    }
    public void setName(String name){
        this.Name = name;
    }

    public String getName(){
        return this.Name;
    }

    public void setEmail(String email){
        this.Email = email;
    }
    public String getEmail(){
        return this.Email;
    }

    public void setPassword(String password){
        this.Password = password;
    }

    public String getPassword(){
        return this.Password;
    }
    

}
