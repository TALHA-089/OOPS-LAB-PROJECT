package com.example.labproject.DashBoards.Teacher.Profile;

import com.example.labproject.DashBoards.Teacher.TeacherDashBoard;
import com.example.labproject.Models.Courses;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.University;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TeacherProfileController {

    public TEACHER teacher = new TEACHER();

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    private Label NameLabel;
    @FXML
    private Label IDLabel;
    @FXML
    private Label EmailLabel;
    @FXML
    private Label PasswordLabel;
    @FXML
    private Label DepartmentLabel;
    @FXML
    private Label CourseLabel;
    @FXML
    private ImageView Back;


    public void loadTeacherInfo(String ID){
        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD)){

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM TEACHER WHERE ID = ?");
            preparedStatement.setString(1,ID);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                teacher.setID(ID);
                teacher.setName(resultSet.getString("NAME"));
                teacher.setEmail(resultSet.getString("EMAIL"));
                teacher.setPassword(resultSet.getString("PASSWORD"));
                teacher.setDepartment(resultSet.getString("DEPARTMENT_NAME"));
                Courses courses = new Courses();
                courses.setCourseName(resultSet.getString("COURSE"));
                teacher.setCourse(courses);
                initializeTeacherinfo(teacher);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private void initializeTeacherinfo(TEACHER teacher) {
        IDLabel.setText(teacher.getID());
        NameLabel.setText(teacher.getName());
        EmailLabel.setText(teacher.getEmail());
        PasswordLabel.setText(teacher.getPassword());
        DepartmentLabel.setText(teacher.getDepartment());
        CourseLabel.setText(teacher.getCourse().getCourseName());
    }


    @FXML
    protected void Exit() throws IOException {
        Stage stage = (Stage) Back.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 300, 350);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(300);
        stage.setMinHeight(350);
        stage.setMaxWidth(300);
        stage.setMaxHeight(350);
        stage.setScene(scene);
        TeacherDashBoard controller = fxmlLoader.getController();
        controller.GlobalTeacher.setID(teacher.getID());
        stage.show();
    }

}
