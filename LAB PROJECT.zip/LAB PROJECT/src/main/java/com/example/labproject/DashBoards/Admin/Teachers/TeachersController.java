package com.example.labproject.DashBoards.Admin.Teachers;

import com.example.labproject.DashBoards.Admin.AdminDashBoard;
import com.example.labproject.Models.Courses;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.University;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeachersController {

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    private Button btnBack;
    @FXML
    private TextField tfTeacherName;
    @FXML
    private TextField tfTeacherID;
    @FXML
    private TextField tfEmail;
    @FXML
    private PasswordField pfPassword;
    @FXML
    private ComboBox<String> cbAvailableCourses;
    @FXML
    private TableView<TEACHER> TeachersTable;
    @FXML
    private TableColumn<TEACHER,String> IDColumn;
    @FXML
    private TableColumn<TEACHER,String> NameColumn;
    @FXML
    private TableColumn<TEACHER,String> EmailColumn;
    @FXML
    private TableColumn<TEACHER,String> PasswordColumn;
    @FXML
    private TableColumn<TEACHER, String> CourseColumn;

    private ObservableList<Courses> courseList = FXCollections.observableArrayList();
    private ObservableList<TEACHER> TeacherList = FXCollections.observableArrayList();



    @FXML
    protected void GoBack() throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/AdminDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(),360,550);
        AdminDashBoard controller = fxmlLoader.getController();
        controller.setDepartment(Department);
        stage.setScene(scene);
        stage.setTitle("ADMIN DASHBOARD");
        stage.setMaxHeight(550);
        stage.setMaxWidth(360);
        stage.setMinWidth(360);
        stage.setMinHeight(550);
        stage.show();
    }

    @FXML
    protected void AddTeacher() {
        String teacherName = tfTeacherName.getText();
        String teacherID = tfTeacherID.getText();
        String email = tfEmail.getText();
        String password = pfPassword.getText();
        String selectedCourse = cbAvailableCourses.getValue();

        if (teacherName.isEmpty() || teacherID.isEmpty() || email.isEmpty() || password.isEmpty() || selectedCourse == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill out all the fields.");
            return;
        }

        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            String checkQuery = "SELECT * FROM TEACHER WHERE ID = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, teacherID);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                showAlert(Alert.AlertType.ERROR, "Error", "Teacher ID already exists.");
                return;
            }


            String insertQuery = "INSERT INTO TEACHER (ID, NAME, EMAIL, PASSWORD, COURSE, DEPARTMENT_NAME) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement insertStmt = conn.prepareStatement(insertQuery);
            insertStmt.setString(1, teacherID);
            insertStmt.setString(2, teacherName);
            insertStmt.setString(3, email);
            insertStmt.setString(4, password);
            insertStmt.setString(5, selectedCourse);
            insertStmt.setString(6, getDepartment());

            int addedRows = insertStmt.executeUpdate();
            if (addedRows > 0) {

                String updateCourseQuery = "UPDATE COURSES SET Teacher = ? WHERE CourseName = ?";
                PreparedStatement updateCourseStmt = conn.prepareStatement(updateCourseQuery);
                updateCourseStmt.setString(1, teacherName);
                updateCourseStmt.setString(2, selectedCourse);
                updateCourseStmt.executeUpdate();


                String updateDepartmentQuery = "UPDATE DEPARTMENTS SET Teachers = CONCAT(IFNULL(Teachers, ''), ?, ', ') WHERE DEPARTMENT_NAME = ?";
                PreparedStatement updateDeptStmt = conn.prepareStatement(updateDepartmentQuery);
                updateDeptStmt.setString(1, teacherName);
                updateDeptStmt.setString(2, getDepartment());
                updateDeptStmt.executeUpdate();


                Courses course = new Courses();
                course.setCourseName(selectedCourse);
                TEACHER newTeacher = new TEACHER(teacherID, teacherName, email, password, getDepartment());
                newTeacher.setCourse(course);

                TeacherList.add(newTeacher);
                clearFields();

                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher added successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to add teacher.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while adding teacher: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void clearFields() {
        tfTeacherName.clear();
        tfTeacherID.clear();
        tfEmail.clear();
        pfPassword.clear();
        cbAvailableCourses.getSelectionModel().clearSelection();
    }


    @FXML
    protected void RemoveTeacher() {
        TEACHER selectedTeacher = TeachersTable.getSelectionModel().getSelectedItem();
        if (selectedTeacher == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a teacher to remove.");
            return;
        }

        String teacherID = selectedTeacher.getID();
        String teacherName = selectedTeacher.getName();
        String courseName = selectedTeacher.getCourse().getCourseName();

        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            String updateDepartmentQuery = "UPDATE DEPARTMENTS SET Teachers = REPLACE(Teachers, ?, '') WHERE DEPARTMENT_NAME = ?";
            PreparedStatement updateDeptStmt = conn.prepareStatement(updateDepartmentQuery);
            updateDeptStmt.setString(1, teacherName + ", ");
            updateDeptStmt.setString(2, selectedTeacher.getDepartment());
            updateDeptStmt.executeUpdate();

            String updateCourseQuery = "UPDATE COURSES SET Teacher = NULL WHERE CourseName = ?";
            PreparedStatement updateCourseStmt = conn.prepareStatement(updateCourseQuery);
            updateCourseStmt.setString(1, courseName);
            updateCourseStmt.executeUpdate();


            String deleteTeacherQuery = "DELETE FROM TEACHER WHERE ID = ?";
            PreparedStatement deleteTeacherStmt = conn.prepareStatement(deleteTeacherQuery);
            deleteTeacherStmt.setString(1, teacherID);
            int deletedRows = deleteTeacherStmt.executeUpdate();

            if (deletedRows > 0) {
                TeacherList.remove(selectedTeacher);
                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher removed successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to remove teacher.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while removing teacher: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @FXML
    protected void EditTeacher() {
        TEACHER selectedTeacher = TeachersTable.getSelectionModel().getSelectedItem();
        if (selectedTeacher == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please select a teacher to edit.");
            return;
        }

        String newTeacherName = tfTeacherName.getText();
        String newTeacherID = tfTeacherID.getText();
        String newEmail = tfEmail.getText();
        String newPassword = pfPassword.getText();
        String newCourseName = cbAvailableCourses.getValue();

        if (newTeacherName.isEmpty() || newTeacherID.isEmpty() || newEmail.isEmpty() || newPassword.isEmpty() || newCourseName == null) {
            showAlert(Alert.AlertType.ERROR, "Error", "Please fill out all the fields.");
            return;
        }

        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            String updateTeacherQuery = "UPDATE TEACHER SET NAME = ?, EMAIL = ?, PASSWORD = ?, COURSE = ? WHERE ID = ?";
            PreparedStatement updateTeacherStmt = conn.prepareStatement(updateTeacherQuery);
            updateTeacherStmt.setString(1, newTeacherName);
            updateTeacherStmt.setString(2, newEmail);
            updateTeacherStmt.setString(3, newPassword);
            updateTeacherStmt.setString(4, newCourseName);
            updateTeacherStmt.setString(5, newTeacherID);
            int updatedRows = updateTeacherStmt.executeUpdate();

            if (updatedRows > 0) {

                String oldCourseName = selectedTeacher.getCourse().getCourseName();
                if (!oldCourseName.equals(newCourseName)) {
                    String resetOldCourseQuery = "UPDATE COURSES SET Teacher = NULL WHERE CourseName = ?";
                    PreparedStatement resetOldCourseStmt = conn.prepareStatement(resetOldCourseQuery);
                    resetOldCourseStmt.setString(1, oldCourseName);
                    resetOldCourseStmt.executeUpdate();
                }


                String updateCourseQuery = "UPDATE COURSES SET Teacher = ? WHERE CourseName = ?";
                PreparedStatement updateCourseStmt = conn.prepareStatement(updateCourseQuery);
                updateCourseStmt.setString(1, newTeacherName);
                updateCourseStmt.setString(2, newCourseName);
                updateCourseStmt.executeUpdate();


                String oldTeacherName = selectedTeacher.getName();
                String updateDepartmentQuery = "UPDATE DEPARTMENTS SET Teachers = REPLACE(Teachers, ?, ?) WHERE DEPARTMENT_NAME = ?";
                PreparedStatement updateDeptStmt = conn.prepareStatement(updateDepartmentQuery);
                updateDeptStmt.setString(1, oldTeacherName + ", ");
                updateDeptStmt.setString(2, newTeacherName + ", ");
                updateDeptStmt.setString(3, selectedTeacher.getDepartment());
                updateDeptStmt.executeUpdate();

                selectedTeacher.setName(newTeacherName);
                selectedTeacher.setEmail(newEmail);
                selectedTeacher.setPassword(newPassword);
                Courses newCourse = new Courses();
                newCourse.setCourseName(newCourseName);
                selectedTeacher.setCourse(newCourse);


                TeachersTable.refresh();
                clearFields();

                showAlert(Alert.AlertType.INFORMATION, "Success", "Teacher updated successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to update teacher.");
            }
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while updating teacher: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @FXML
    protected void initialize(){
        NameColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
        IDColumn.setCellValueFactory(new PropertyValueFactory<>("ID"));
        EmailColumn.setCellValueFactory(new PropertyValueFactory<>("Email"));
        PasswordColumn.setCellValueFactory(new PropertyValueFactory<>("Password"));
        CourseColumn.setCellValueFactory(cellData -> {
            Courses course = cellData.getValue().getCourse();
            StringProperty nameProperty = new SimpleStringProperty(course.getCourseName());
            return nameProperty;
        });

        loadTeachersFromDataBase();
        TeachersTable.setItems(TeacherList);
        loadCoursesFromDatabase();
        List<String> courseNames = new ArrayList<>();
        for (Courses course : courseList) {
            courseNames.add(course.getCourseName());
        }
        cbAvailableCourses.setItems(FXCollections.observableArrayList(courseNames));
    }



    private String Department;

    public void setDepartment(String Department){
        this.Department = Department;
    }

    public String getDepartment(){
        return this.Department;
    }

    private void loadCoursesFromDatabase() {
        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM COURSES WHERE Teacher = ?");
            preparedStatement.setString(1,"DummyTeacher");

            ResultSet rs = preparedStatement.executeQuery();

            List<Courses> courses = new ArrayList<>();
            while (rs.next()) {
                TEACHER teacher = new TEACHER();
                Courses course = new Courses(
                        rs.getString("CourseName"),
                        rs.getString("CourseCode"),
                        teacher,
                        rs.getInt("CreditHours"),
                        rs.getString("DEPARTMENT_NAME")
                );
                courses.add(course);
            }
            courseList.addAll(courses);

        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while loading courses: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private void loadTeachersFromDataBase() {
        try {
            Connection conn = getConnection();
            if (conn == null) {
                showAlert(Alert.AlertType.ERROR, "Error", "Failed to connect to database.");
                return;
            }

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM TEACHER");
            ResultSet rs = preparedStatement.executeQuery();

            List<TEACHER> teachers = new ArrayList<>();

            while(rs.next()) {
                Courses course = new Courses();
                course.setCourseName(rs.getString("COURSE"));
                TEACHER teacher = new TEACHER(
                        rs.getString("ID"),
                        rs.getString("NAME"),
                        rs.getString("EMAIL"),
                        rs.getString("PASSWORD"),
                        rs.getString("DEPARTMENT_NAME")
                );
                teacher.setCourse(course);

                teachers.add(teacher);
            }
            TeacherList.addAll(teachers);
        } catch (SQLException e) {
            showAlert(Alert.AlertType.ERROR, "Exception", "Exception occurred while loading teachers: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String content) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
    }
}
