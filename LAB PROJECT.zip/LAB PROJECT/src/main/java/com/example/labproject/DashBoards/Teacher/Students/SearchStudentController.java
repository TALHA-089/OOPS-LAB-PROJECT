package com.example.labproject.DashBoards.Teacher.Students;

import com.example.labproject.DashBoards.Teacher.TeacherDashBoard;
import com.example.labproject.Models.TEACHER;
import com.example.labproject.University;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SearchStudentController {

    public TEACHER teacher = new TEACHER();

    @FXML
    private ImageView Back;

    @FXML
    private TextField tfEnrollment;

    @FXML
    private Label NameLabel;
    @FXML
    private Label IDLabel;
    @FXML
    private Label EmailLabel;
    @FXML
    private Label PasswordLabel;
    @FXML
    private Label ClassLabel;
    @FXML
    private Label DepartmentLabel;
    @FXML
    private Label SemesterLabel;

    final String DB_URL = "jdbc:mysql://localhost/LABPROJECT?serverTimezone=UTC";
    final String USERNAME = "root";
    final String PASSWORD = "Talha@786";

    @FXML
    protected void Exit() throws IOException{
        Stage stage = (Stage) Back.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(University.class.getResource("/FXMLS/DashBoards/TeacherDashBoard.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 300, 350);
        stage.setTitle("WELCOME!");
        stage.setMinWidth(300);
        stage.setMinHeight(350);
        stage.setMaxWidth(300);
        stage.setMaxHeight(350);
        stage.setScene(scene);
        TeacherDashBoard controller = fxmlLoader.getController();
        controller.GlobalTeacher.setID(teacher.getID());
        stage.show();
    }

    @FXML
    protected void Search(){
        String enrollment = tfEnrollment.getText();

        if(enrollment.isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText(null);
            alert.setContentText("Please Provide an Enrollment!");
            alert.showAndWait();
            return;
        }

        try(Connection conn = DriverManager.getConnection(DB_URL,USERNAME,PASSWORD)){

            PreparedStatement preparedStatement = conn.prepareStatement("SELECT * FROM STUDENT WHERE ID = ?");
            preparedStatement.setString(1,enrollment);
            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("SUCCESS");
                alert.setHeaderText(null);
                alert.setContentText("Found the Student!");
                alert.showAndWait();
                IDLabel.setText(resultSet.getString("ID"));
                NameLabel.setText(resultSet.getString("NAME"));
                EmailLabel.setText(resultSet.getString("EMAIL"));
                PasswordLabel.setText(resultSet.getString("PASSWORD"));
                DepartmentLabel.setText(resultSet.getString("DEPARTMENT_NAME"));
                SemesterLabel.setText(String.valueOf(resultSet.getString("Semester")));
                ClassLabel.setText(resultSet.getString("Class"));
                tfEnrollment.clear();
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
